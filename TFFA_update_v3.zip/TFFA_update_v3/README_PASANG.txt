TFFA UPDATE v3: STAFF + PANEL GUI + HEWAN MENJADI POKEMON
==========================================================
Paket ini sudah mencakup v2 (staff dan panel). Pakai v3 saja.
Isi: (1) role staff + nametag, (2) panel STAFF (GUI), (3) hewan -> Pokémon.

LANGKAH PASANG (Roblox Studio). Setiap file = satu script; isi script diisi dengan isi file bernama sama.

BARU (buat script baru, semuanya ModuleScript):
 1. ReplicatedStorage/Config/StaffConfig
 2. ReplicatedStorage/Config/PokemonConfig                                    <- pemetaan 178 hewan -> Pokémon + ID aset
 3. ReplicatedStorage/CmdrClient/Types/StaffRoleType
 4. ReplicatedStorage/CmdrClient/Commands/SetRole
 5. ReplicatedStorage/CmdrClient/Commands/StaffList
 6. ServerScriptService/Server/StaffService
 7. ServerScriptService/Server/ModerationService
 8. ServerScriptService/Server/StaffPanelService
 9. ServerScriptService/Server/PokemonService
10. StarterPlayer/StarterPlayerScripts/Client/Controllers/StaffPanel
11. StarterPlayer/StarterPlayerScripts/Client/Controllers/StaffPoll
12. StarterPlayer/StarterPlayerScripts/Client/Controllers/PokemonController

GANTI ISI (script sudah ada; perubahan kecil ditandai):
13. ReplicatedStorage/Config/AdminsConfig
14. ReplicatedStorage/CmdrClient/Types/BeforeRun
15. ReplicatedStorage/Config/ReleaseConfig        (1 baris: Owners mengikuti StaffConfig)
16. ReplicatedStorage/Shared/Remotes              (+3 nama remote)
17. ReplicatedStorage/AnimalsData                 (nama tampilan 176 hewan diganti jadi nama Pokémon)
18. ServerScriptService/Server/Main               (+StaffService, StaffPanelService, PokemonService)
19. ServerScriptService/CmdrServer                (+ setrole, stafflist, StaffPanel.BindImpl)
20. StarterPlayer/StarterPlayerScripts/Client/ClientMain/init   (+ PokemonController, StaffPanel, StaffPoll)

------------------------------------------------------------------------------------------
BAGIAN 1-2: STAFF DAN PANEL
 Developer = 2 owner (10522335269 dan 8663872118). Admin = banyak, diatur Developer. Content Creator = nametag saja.
 Buka panel dengan tombol "STAFF" (kiri tengah layar) atau F3. Konsol perintah lama tetap F2 / /cmdr.
 Tab: Players (Kick, Ban, Unban, Mute, Unmute, Slap, Freeze, Unfreeze, Kill, Respawn, Bring, Go to, Streamer ON/OFF),
      Announce, Poll  -> Admin dan Developer.
      Boosts, Event, Staff -> Developer saja (economy dan pengaturan penuh).
 Semua aksi dicek ulang di server. Admin tidak bisa menindak staff setingkat/lebih tinggi.
 Detail lain: lihat catatan v2 di bawah.

BAGIAN 3: HEWAN -> POKEMON
 Cara kerja
  - Saat server menyala, PokemonService memuat aset Pokémon dari Creator Store (InsertService), membuang semua script dan efek di
    dalamnya, menyamakan ukurannya dengan model hewan aslinya, lalu menaruhnya di ReplicatedStorage.PokemonAnimals.
  - Game memakai model itu lewat AnimalTemplates.SetOverride (hook yang sudah ada di kode). Kalau satu aset gagal dimuat,
    hewan itu otomatis memakai model aslinya. Model asli tidak dihapus.
  - Pemuatan berjalan di latar belakang sekitar 1-2 menit setelah server menyala; hewan berganti tampilan begitu modelnya siap.
  - Cek hasilnya di Output server: "[Pokemon] x/176 model Pokémon dimuat" dan daftar yang gagal.
 Pemetaan (lihat TFFA_pemetaan_pokemon.csv)
  - 178 hewan dipasangkan satu-satu dengan 178 Pokémon di CSV Anda: hewan makin langka <-> Pokémon makin kuat
    (urutan base stat total perkiraan). Contoh: Snail -> Caterpie, ..., Crownbreaker Aurochs -> Mewtwo.
  - Nama tampilan 176 hewan diganti jadi nama Pokémon (AnimalsData). Nama asli ada di kolom "Nama asli hewan" di CSV.
  - Mau ganti pasangan atau aset? Edit baris di PokemonConfig.Map. Mau matikan semuanya? PokemonConfig.Enabled = false.
 Yang belum beres
  - 2 Pokémon belum punya aset yang layak di CSV: Nidoran♀ (hewan Llama) dan Omastar (HarlequinHyena). Dua hewan itu tetap
    memakai model dan nama asli sampai Anda mengisi Assets-nya di PokemonConfig.
  - Nidoran♂ (hewan Turtle) memakai satu-satunya kandidat "nidoran(male)"; cek di Studio.
  - Semua aset adalah kandidat dari pencarian Creator Store dan BELUM dicek bentuk aslinya. Pilihan otomatis memakai judul yang
    cocok persis dengan nama Pokémon, tanpa kata seperti mega/shiny/pack. Cadangan 2-3 aset per Pokémon dicoba berurutan.
  - Model Creator Store tidak punya rig/animasi seperti hewan asli, jadi tampil sebagai model diam. Arah hadap bisa berbeda:
    putar dengan PokemonConfig.FaceFix["NamaModel"] = derajat.
  - Aset yang tidak bisa dipakai game ini (privat, dihapus, atau tidak boleh dimuat lewat InsertService) otomatis dilewati.
  - Pokémon adalah merek milik pihak lain dan aset-asetnya buatan orang lain: ada risiko aset atau game dimoderasi Roblox.
 Keamanan: isi aset dianggap tidak tepercaya. Semua Script/LocalScript/ModuleScript, suara, efek, lampu, GUI, dan remote di dalam
 model dibuang sebelum dipakai.

------------------------------------------------------------------------------------------
CATATAN v2 (staff dan panel)
 - "setstreamer" = menjadikan pemain Content Creator (nametag ungu) atau mencabutnya. Admin tidak bisa mengubah Admin/Developer.
 - Polling berjalan per server. Announce bisa ke semua server.
 - Mute memakai TextChatService. Kalau game memakai chat lama, mute tidak memblokir chat.
 - Ban memakai Players:BanAsync. Tes ban/unban di game yang sudah dipublish, bukan di Studio.
 - Event admin abuse "Start" menjalankan timeline 30 menit di server itu saja.
 - Pesan hasil aksi economy (give/boost) masih berbahasa Prancis karena berasal dari kode asli CmdrServer.
 - Panel DEV (tombol oranye): owner lama (MisfitsBS, 2735356267) DIGANTI oleh 2 owner baru; tombolnya masih belum berfungsi
   karena server Dev_Action memang kosong di kode asli.
 - Admin lama (daftar FastFlag) tidak dipakai lagi: daftarkan ulang lewat tab Staff atau setrole.
 - Di Studio semua pemain dianggap Developer (StaffConfig.StudioEveryoneIsDeveloper), data staff disimpan terpisah.
 - Kode belum dijalankan di Roblox (tidak ada Luau di lingkungan pembuatnya). Tes dulu di Studio, lalu di game publish.
