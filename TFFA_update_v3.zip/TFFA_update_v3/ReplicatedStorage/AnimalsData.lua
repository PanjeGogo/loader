
return {
	Forest = {
		{ ModelName = "Snail", Name = "Caterpie" },
		{ ModelName = "Frog", Name = "Weedle" },
		{ ModelName = "Bunny", Name = "Magikarp" },
		{ ModelName = "Owl", Name = "Igglybuff" },
		{ ModelName = "Kookaburra", Name = "Sentret" },
		{ ModelName = "Badger", Name = "Cleffa" },
		{ ModelName = "Cow", Name = "Ditto" },
		{ ModelName = "Pony", Name = "Doduo" }
	},
	Savana = {
		{ ModelName = "Ostrich", Name = "Metapod" },
		{ ModelName = "Quokka", Name = "Kakuna" },
		{ ModelName = "Giraffee", Name = "Zubat" },
		{ ModelName = "Hyena", Name = "Togepi" },
		{ ModelName = "Zebra", Name = "Spinarak" },
		{ ModelName = "Aardvark", Name = "Meowth" },
		{ ModelName = "Elephant", Name = "Horsea" },
		{ ModelName = "Lion", Name = "Gastly" }
	},
	Desert = {
		{ ModelName = "Hamster", Name = "Pichu" },
		{ ModelName = "StymphalianBird", Name = "Pidgey" },
		{ ModelName = "Emu", Name = "Rattata" },
		{ ModelName = "Snake", Name = "Spearow" },
		{ ModelName = "Dingo", Name = "Vulpix" },
		{ ModelName = "Jackal", Name = "Sandshrew" },
		{ ModelName = "Horse", Name = "Squirtle" },
		{ ModelName = "Kangaroo", Name = "Totodile" }
	},
	Jungle = {
		{ ModelName = "Lizard", Name = "Hoothoot" },
		{ ModelName = "Bat", Name = "Diglett" },
		{ ModelName = "Parrot", Name = "Ledyba" },
		{ ModelName = "Koala", Name = "Poliwag" },
		{ ModelName = "Cobra", Name = "Bellsprout" },
		{ ModelName = "Crocodile", Name = "Slowpoke" },
		{ ModelName = "Tiger", Name = "Bulbasaur" },
		{ ModelName = "Gorilla", Name = "Chinchou" }
	},
	Ocean = {
		{ ModelName = "Crab", Name = "Jigglypuff" },
		{ ModelName = "Turtle", Name = "Nidoran♂" },
		{ ModelName = "Jellyfish", Name = "Geodude" },
		{ ModelName = "GoblinShark", Name = "Dratini" },
		{ ModelName = "Seahorse", Name = "Chikorita" },
		{ ModelName = "MantisShrimp", Name = "Pikachu" },
		{ ModelName = "LeafySeaDragon", Name = "Tentacool" },
		{ ModelName = "Seal", Name = "Koffing" }
	},
	Mountains = {
		{ ModelName = "Llama", Name = "Llama" },
		{ ModelName = "GuiennaPig", Name = "Venonat" },
		{ ModelName = "Roc", Name = "Mankey" },
		{ ModelName = "Capybara", Name = "Oddish" },
		{ ModelName = "Thunderbird", Name = "Psyduck" },
		{ ModelName = "Bull", Name = "Staryu" },
		{ ModelName = "Yak", Name = "Rhyhorn" },
		{ ModelName = "Griffin", Name = "Kadabra" }
	},
	Taiga = {
		{ ModelName = "HoneyBadger", Name = "Machop" },
		{ ModelName = "Cockatrice", Name = "Shellder" },
		{ ModelName = "Caracal", Name = "Cubone" },
		{ ModelName = "Wolf", Name = "Goldeen" },
		{ ModelName = "Jackalope", Name = "Pidgeotto" },
		{ ModelName = "Bear", Name = "Growlithe" },
		{ ModelName = "Kitsune", Name = "Ivysaur" },
		{ ModelName = "Fenrir", Name = "Charmeleon" }
	},
	Winter = {
		{ ModelName = "GoldenRetriver", Name = "Charmander" },
		{ ModelName = "Goat", Name = "Natu" },
		{ ModelName = "Tanuki", Name = "Clefairy" },
		{ ModelName = "Caladrius", Name = "Omanyte" },
		{ ModelName = "Polar Bear", Name = "Kabuto" },
		{ ModelName = "Mamoth", Name = "Wartortle" },
		{ ModelName = "Lindworm", Name = "Parasect" },
		{ ModelName = "SaberToothedTiger", Name = "Persian" }
	},
	PrehistoricForest = {
		{ ModelName = "Pterodactyl", Name = "Magnemite" },
		{ ModelName = "Triceratops", Name = "Seel" },
		{ ModelName = "Dimetrodon", Name = "Nidorina" },
		{ ModelName = "Gallimimus", Name = "Nidorino" },
		{ ModelName = "Brachiosaurus", Name = "Machoke" },
		{ ModelName = "Spinosaurus", Name = "Haunter" },
		{ ModelName = "T-Rex", Name = "Seadra" },
		{ ModelName = "Velicoraptor", Name = "Fearow" }
	},
	DeepWaters = {
		{ ModelName = "Anglerfish", Name = "Grimer" },
		{ ModelName = "Swordfish", Name = "Farfetch'd" },
		{ ModelName = "Shark", Name = "Poliwhirl" },
		{ ModelName = "Whale", Name = "Bayleef" },
		{ ModelName = "Megalodon", Name = "Quilava" },
		{ ModelName = "Mosasaurus", Name = "Noctowl" },
		{ ModelName = "Kraken", Name = "Sandslash" },
		{ ModelName = "Plesiosaur", Name = "Clefable" }
	},
	Hell = {
		{ ModelName = "Mothman", Name = "Eevee" },
		{ ModelName = "Bunyip", Name = "Drowzee" },
		{ ModelName = "GargoyleBat", Name = "Butterfree" },
		{ ModelName = "WingedImp", Name = "Gloom" },
		{ ModelName = "Manticore", Name = "Arbok" },
		{ ModelName = "Chupacabra", Name = "Togetic" },
		{ ModelName = "Dullahan", Name = "Primeape" },
		{ ModelName = "Cerberus", Name = "Lanturn" }
	},
	AncientRuins = {
		{ ModelName = "TripleCobra", Name = "Voltorb" },
		{ ModelName = "Leviathan", Name = "Porygon" },
		{ ModelName = "Microraptor", Name = "Graveler" },
		{ ModelName = "Archaeopteryx", Name = "Ponyta" },
		{ ModelName = "Qilin", Name = "Dragonair" },
		{ ModelName = "Sphinx", Name = "Dewgong" },
		{ ModelName = "Minotaur", Name = "Kingler" },
		{ ModelName = "Hydra", Name = "Vileplume" }
	},
	MythicalParadise = {
		{ ModelName = "Raiju", Name = "Ledian" },
		{ ModelName = "Unicorn", Name = "Beedrill" },
		{ ModelName = "Pegasus", Name = "Dugtrio" },
		{ ModelName = "Simurgh", Name = "Tangela" },
		{ ModelName = "Amphiptere", Name = "Golbat" },
		{ ModelName = "Wyvern", Name = "Hitmonlee" },
		{ ModelName = "ClassicDragon", Name = "Weezing" },
		{ ModelName = "FirePhoenix", Name = "Golem" }
	},
	ShadowRealm = {
		{ ModelName = "BlackCat", Name = "Ariados" },
		{ ModelName = "CursedRaven", Name = "Marowak" },
		{ ModelName = "CursedOwl", Name = "Croconaw" },
		{ ModelName = "ShadowWolf", Name = "Mr. Mime" },
		{ ModelName = "PhantomDog", Name = "Xatu" },
		{ ModelName = "Hellhound", Name = "Golduck" },
		{ ModelName = "ShadowDemon", Name = "Electrode" },
		{ ModelName = "Nightmare", Name = "Poliwrath" }
	},
	HarvestFields = {
		{ ModelName = "RavenHalloween", Name = "Furret" },
		{ ModelName = "ZombieCrow", Name = "Wigglytuff" },
		{ ModelName = "Scarecrow", Name = "Seaking" },
		{ ModelName = "WitchFamiliarCat", Name = "Hitmonchan" },
		{ ModelName = "JackOLantern", Name = "Magmar" },
		{ ModelName = "Witch", Name = "Alakazam" },
		{ ModelName = "Golem", Name = "Nidoqueen" },
		{ ModelName = "Horseman", Name = "Machamp" }
	},
	PhantomHarbor = {
		{ ModelName = "Ghost", Name = "Raticate" },
		{ ModelName = "Poltergeist", Name = "Dodrio" },
		{ ModelName = "Wraith", Name = "Pidgeot" },
		{ ModelName = "Specter", Name = "Slowbro" },
		{ ModelName = "Banshee", Name = "Tauros" },
		{ ModelName = "GhostlyHorse", Name = "Venusaur" },
		{ ModelName = "Lich", Name = "Pinsir" },
		{ ModelName = "GhostPirate", Name = "Meganium" }
	},
	NuclearWasteland = {
		{ ModelName = "ReactorHound", Name = "Jynx" },
		{ ModelName = "UraniumStag", Name = "Magneton" },
		{ ModelName = "BarrelBrute", Name = "Kabutops" },
		{ ModelName = "SludgeMimic", Name = "Victreebel" },
		{ ModelName = "ReactorGolem", Name = "Electabuzz" },
		{ ModelName = "SirenSpire", Name = "Starmie" },
		{ ModelName = "GlassbackColossus", Name = "Scyther" },
		{ ModelName = "IsotopeAngel", Name = "Ninetales" },
		{ ModelName = "FerroWyrm", Name = "Feraligatr" },
		{ ModelName = "RadScarecrow", Name = "Cloyster" },
		{ ModelName = "MeltdownIdol", Name = "Crobat" },
		{ ModelName = "WasteHarvester", Name = "Articuno" }
	},
	CursedCarnival = {
		{ ModelName = "VampireBat", Name = "Kangaskhan" },
		{ ModelName = "HarlequinHyena", Name = "Harlequin Hyena" },
		{ ModelName = "SilverbackGorilla", Name = "Gengar" },
		{ ModelName = "BlackPanther", Name = "Nidoking" },
		{ ModelName = "MarionetteMantis", Name = "Tentacruel" },
		{ ModelName = "IronhideRhino", Name = "Rapidash" },
		{ ModelName = "PhantomTiger", Name = "Jolteon" },
		{ ModelName = "SpectralMammoth", Name = "Blastoise" },
		{ ModelName = "NightmareGriffin", Name = "Dragonite" },
		{ ModelName = "CircusChimera", Name = "Lapras" },
		{ ModelName = "RingmasterRevenant", Name = "Snorlax" },
		{ ModelName = "DreadmaneBehemoth", Name = "Zapdos" }
	},
	EclipseKingdom = {
		{ ModelName = "SunspotJerboa", Name = "Aerodactyl" },
		{ ModelName = "CrescentIbis", Name = "Muk" },
		{ ModelName = "LanternPangolin", Name = "Flareon" },
		{ ModelName = "CrownIbex", Name = "Exeggutor" },
		{ ModelName = "MoondialRam", Name = "Charizard" },
		{ ModelName = "OrreryCrane", Name = "Vaporeon" },
		{ ModelName = "VeilwingLynx", Name = "Arcanine" },
		{ ModelName = "GildedHippocampus", Name = "Moltres" },
		{ ModelName = "CoronaSalamander", Name = "Typhlosion" },
		{ ModelName = "RoyalLamassu", Name = "Gyarados" },
		{ ModelName = "CrownbreakerAurochs", Name = "Mewtwo" },
		{ ModelName = "EclipseDragon", Name = "Mew" }
	},
	Shop = {
		{ ModelName = "LivingPumpkin", Name = "Venomoth" },
		{ ModelName = "GiantSquid", Name = "Hypno" },
		{ ModelName = "WoollyMammoth", Name = "Onix" },
		{ ModelName = "Skeleton", Name = "Paras" },
		{ ModelName = "SkeletonHorse", Name = "Cyndaquil" },
		{ ModelName = "Demon", Name = "Krabby" },
		{ ModelName = "ReaperSteed", Name = "Lickitung" },
		{ ModelName = "Reaper", Name = "Raichu" },
		{ ModelName = "FairyFox", Name = "Ekans" },
		{ ModelName = "MushroomBear", Name = "Abra" },
		{ ModelName = "MysticMandrake", Name = "Exeggcute" },
		{ ModelName = "SpellboundOwl", Name = "Weepinbell" },
		{ ModelName = "JadeKirin", Name = "Rhydon" },
		{ ModelName = "ArcanePhoenix", Name = "Chansey" }
	}
}