-- Perintah: setrole <player> <admin|creator|none>   (hanya Developer)
-- Letak di Studio: ReplicatedStorage > CmdrClient > Commands > SetRole (ModuleScript)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.Shared.CmdrUtil)

return {
	Name = "setrole",
	Description = "Sets a player's staff role: admin, creator (content creator) or none to remove it. Developers only.",
	Group = "Admin",
	Args = {
		{ Type = "playerId", Name = "Player", Description = "Name or UserId (can be offline)" },
		{ Type = "staffRole", Name = "Role", Description = "admin, creator or none" },
	},
}
