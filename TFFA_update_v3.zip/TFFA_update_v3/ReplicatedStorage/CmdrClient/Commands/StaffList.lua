-- Perintah: stafflist   (Developer dan Admin)
-- Letak di Studio: ReplicatedStorage > CmdrClient > Commands > StaffList (ModuleScript)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

require(ReplicatedStorage.Shared.CmdrUtil)

return {
	Name = "stafflist",
	Description = "Lists every Developer, Admin and Content Creator.",
	Group = "Admin",
	Args = {},
}
