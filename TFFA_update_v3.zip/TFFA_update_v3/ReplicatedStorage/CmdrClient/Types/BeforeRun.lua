-- BeforeRun (PENGGANTI file lama): cek rank sebelum perintah dijalankan.
-- Letak di Studio: ReplicatedStorage > CmdrClient > Types > BeforeRun (ModuleScript)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local AdminsConfig = require(ReplicatedStorage.Config.AdminsConfig)
local StaffConfig = require(ReplicatedStorage.Config.StaffConfig)
require(ReplicatedStorage.Shared.CmdrUtil)

return function(registry)
	registry:RegisterHook("BeforeRun", function(p)
		local rank = AdminsConfig.GetRank(p.Executor)

		if rank == nil then
			return "You do not have permission to run commands."
		end

		if not StaffConfig.CanRun(rank, p.Name) then
			return "Your rank (" .. rank .. ") cannot run this command."
		end

		return nil
	end)
end
