-- Tipe argumen "staffRole" untuk perintah setrole (admin / creator / none).
-- Letak di Studio: ReplicatedStorage > CmdrClient > Types > StaffRoleType (ModuleScript)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CmdrUtil = require(ReplicatedStorage.Shared.CmdrUtil)

local roles = {
	{ Name = "admin", Value = "Admin" },
	{ Name = "creator", Aliases = { "contentcreator", "cc" }, Value = "ContentCreator" },
	{ Name = "none", Aliases = { "remove" }, Value = "None" },
}

local function GetRoles()
	return roles
end

return function(registry)
	registry:RegisterType("staffRole", CmdrUtil.MakeCatalogType("staff role", GetRoles))
end
