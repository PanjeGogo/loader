-- AdminsConfig (PENGGANTI file lama): sekarang membaca role dari attribute Player
-- yang diisi server oleh StaffService. API lama tetap ada supaya script lain tidak rusak.
-- Letak di Studio: ReplicatedStorage > Config > AdminsConfig (ModuleScript)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local StaffConfig = require(ReplicatedStorage.Config.StaffConfig)

local ATTRIBUTE = StaffConfig.Attribute

-- Hasil: "Developer", "Admin", "ContentCreator", atau nil (pemain biasa).
local function GetRank(player)
	if not player then
		return nil
	end

	local role = player:GetAttribute(ATTRIBUTE)
	if type(role) == "string" and StaffConfig.Roles[role] then
		return role
	end

	return nil
end

-- True kalau boleh memakai panel admin (Developer dan Admin).
local function GetIsAdmin(player)
	local rank = GetRank(player)
	local def = rank and StaffConfig.Roles[rank]
	return def ~= nil and def.Panel == true
end

-- True untuk semua staff, termasuk Content Creator.
local function GetIsStaff(player)
	return GetRank(player) ~= nil
end

return table.freeze({
	-- Daftar Developer tetap (Admin dan Content Creator ada di DataStore, lihat StaffService.List).
	GetAdminUserIds = function()
		return table.clone(StaffConfig.Developers)
	end,
	GetIsAdmin = GetIsAdmin,
	GetIsStaff = GetIsStaff,
	GetRank = GetRank,
	-- Dipanggil saat role pemain lokal berubah (hanya berguna di client).
	OnChanged = function(callback)
		local localPlayer = Players.LocalPlayer
		if localPlayer then
			localPlayer:GetAttributeChangedSignal(ATTRIBUTE):Connect(function()
				callback()
			end)
		end
	end,
})
