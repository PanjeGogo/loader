
local RunService = game:GetService("RunService")

local ReleaseConfig = {}

ReleaseConfig.Released = {
	ShadowRealm = true,
	Upcoming = false,
	HarvestHarbor = false,
	NuclearUpdate = false,
	NuclearWasteland = false,
	CarnivalUpdate = false,
	CursedCarnival = false,
	EclipseKingdom = false
}

ReleaseConfig.Schedule = {
	ShadowRealm = {
		Year = 2026,
		Month = 10,
		Day = 6,
		Hour = 22,
		Minute = 0,
		UtcOffset = 2
	},
	HarvestHarbor = {
		Year = 2026,
		Month = 10,
		Day = 25,
		Hour = 19,
		Minute = 0,
		UtcOffset = 1
	},
	NuclearUpdate = {
		Year = 2026,
		Month = 10,
		Day = 31,
		Hour = 17,
		Minute = 0,
		UtcOffset = 1
	},
	NuclearWasteland = {
		Year = 2026,
		Month = 10,
		Day = 31,
		Hour = 17,
		Minute = 30,
		UtcOffset = 1
	},
	CarnivalUpdate = {
		Year = 2026,
		Month = 11,
		Day = 7,
		Hour = 15,
		Minute = 0,
		UtcOffset = 1
	},
	CursedCarnival = {
		Year = 2026,
		Month = 11,
		Day = 7,
		Hour = 15,
		Minute = 0,
		UtcOffset = 1
	},
	EclipseKingdom = {
		Year = 2026,
		Month = 11,
		Day = 7,
		Hour = 15,
		Minute = 0,
		UtcOffset = 1
	}
}

ReleaseConfig.ByProgress = {
	HarvestHarbor = { FromArea = 7 },
	NuclearWasteland = { FromArea = 14 },
	CursedCarnival = { FromArea = 16 },
	EclipseKingdom = { FromArea = 17 }
}

ReleaseConfig.Show = {
	HarvestHarbor = {
		Title = "2 NEW MAPS!",
		SmallText = "2 new maps are out!",
		Maps = { "HarvestFields", "PhantomHarbor" },
		BigFromArea = 7
	},
	NuclearWasteland = {
		Title = "NEW MAP!",
		SmallText = "A new map is out!",
		Maps = { "NuclearWasteland" },
		BigFromArea = 11,
		CutsceneFromArea = 14
	},
	CursedCarnival = {
		Title = "2 NEW MAPS!",
		SmallText = "2 new maps are out!",
		Maps = { "CursedCarnival", "EclipseKingdom" },
		BigFromArea = 14
	}
}

ReleaseConfig.Events = {
	HarvestHarbor = { EventId = "204931155982680674" },
	NuclearUpdate = { EventId = "8035145520026616433" },
	CarnivalUpdate = { EventId = "5307010046343905940" }
}

ReleaseConfig.EventFollow = {
	AskAfterMinutes = 20,
	AskFrom = { Area = "Ocean", Part = 0 },
	MaxAsks = 2,
	AskGapMinutes = 20,
	TrainingSeconds = 4,
	IdleSeconds = 12
}

ReleaseConfig.StandInFrom = {}
ReleaseConfig.StudioPreview = false
ReleaseConfig.StudioTestReleaseIn = nil
ReleaseConfig.DevServer = {
	Owners = require(script.Parent.StaffConfig).DeveloperMap, -- sama dengan Developer di StaffConfig
	Keys = {
		HarvestHarbor = true,
		NuclearWasteland = true,
		CursedCarnival = true,
		EclipseKingdom = true
	},
	ReservedServers = true,
	StudioTest = false,
	StudioOpensKeys = false
}

ReleaseConfig.DevGame = {
	GameIds = { [10774495967] = true },
	OpenKeys = false,
	Studio = true
}

local isStudio = RunService:IsStudio()

local v = nil
function ReleaseConfig.IsDevServer()
	if v ~= nil then
		return v
	end

	local devServer = ReleaseConfig.DevServer

	if not RunService:IsRunning() then
		return false
	end

	if RunService:IsServer() then
		local v2, v3

		if game.PrivateServerId == "" then
			v2 = false
			v3 = 0
		else
			v3 = game.PrivateServerOwnerId
			v2 = v3 == 0
		end

		local v4

		if v2 and devServer.ReservedServers == true then
			local success, result = pcall(function()
				local ServerScriptService = game:GetService("ServerScriptService")
				local server = ServerScriptService:WaitForChild("Server", 10)
				local ServerKind = require(server:WaitForChild("ServerKind", 10))
				return ServerKind.ReservedKind()
			end)
			v4 = success and result == "Dev"
		else
			v4 = false
		end

		v = v3 ~= 0 and devServer.Owners[v3] ~= nil or (v4 or isStudio and devServer.StudioTest == true)
		workspace:SetAttribute("DevServer", v)
		return v
	else
		local devServer2 = workspace:GetAttribute("DevServer")

		if devServer2 == nil then
			local lastTime = os.clock()

			repeat
				task.wait()
				devServer2 = workspace:GetAttribute("DevServer")
			until devServer2 ~= nil or os.clock() - lastTime > 10
		end

		v = devServer2 == true
		return v
	end
end

function ReleaseConfig.IsDeveloper(p): boolean
	return p ~= nil and ReleaseConfig.DevServer.Owners[p.UserId] ~= nil
end

local function devGameOpen(): boolean -- 3 equivalent calls inferred from this helper
	local devGame = ReleaseConfig.DevGame

	if devGame and devGame.OpenKeys == true and devGame.GameIds[game.GameId] then
		return not isStudio or devGame.Studio == true
	end

	return false
end

local function devKeysOpen(): boolean
	if devGameOpen() then -- inferred equivalent call
		return true
	end

	if ReleaseConfig.IsDevServer() then
		return not isStudio or ReleaseConfig.DevServer.StudioOpensKeys == true
	end

	return false
end

function ReleaseConfig.IsOn(p)
	if p == nil or ReleaseConfig.Released[p] or ReleaseConfig.Schedule[p] then
		return true
	end

	if not ReleaseConfig.DevServer.Keys[p] then
		return ReleaseConfig.StudioPreview == true and isStudio
	end

	local v2 = devGameOpen() -- inferred equivalent call
	local v3

	if v2 then
		v3 = true
	elseif ReleaseConfig.IsDevServer() then
		v3 = not isStudio or ReleaseConfig.DevServer.StudioOpensKeys == true
	else
		v3 = false
	end

	if v3 then
		return true
	end

	return ReleaseConfig.StudioPreview == true and isStudio
end

function ReleaseConfig.IsDevOpen(p): boolean
	local _

	if p == nil or ReleaseConfig.DevServer.Keys[p] ~= true then
		_ = false
		return false
	end

	if devGameOpen() then -- inferred equivalent call
		return true
	end

	if not ReleaseConfig.IsDevServer() then
		return false
	end

	return not isStudio or ReleaseConfig.DevServer.StudioOpensKeys == true
end

function ReleaseConfig.IsScheduled(p)
	local v2

	if p == nil then
		return false
	end

	v2 = not ReleaseConfig.Released[p]

	if v2 then
		if ReleaseConfig.Schedule[p] == nil then
			return false
		end

		return not ReleaseConfig.IsDevOpen(p)
	end

	return v2
end

function ReleaseConfig.IsUnlocked(p)
	if p == nil or ReleaseConfig.Released[p] then
		return true
	end

	if ReleaseConfig.Schedule[p] and not ReleaseConfig.IsDevOpen(p) then
		return workspace:GetAttribute("Unlocked_" .. p) == true
	end

	return ReleaseConfig.IsOn(p)
end

local function toUnix(data) -- 3 equivalent calls inferred from this helper
	return DateTime.fromUniversalTime(data.Year, data.Month, data.Day, 0, 0, 0).UnixTimestamp + ((data.Hour or 0) - (data.UtcOffset or 0)) * 3600 + (data.Minute or 0) * 60
end

function ReleaseConfig.EventId(p)
	local v2 = p and ReleaseConfig.Events[p]
	return v2 and v2.EventId or nil
end

function ReleaseConfig.ScheduledTime(p)
	local v2 = ReleaseConfig.Schedule[p]

	if v2 then
		return toUnix(v2) -- inferred equivalent call
	end

	return nil
end

function ReleaseConfig.StandInTime(p)
	local v2 = ReleaseConfig.StandInFrom[p]

	if not v2 or isStudio and (type(ReleaseConfig.StudioTestReleaseIn) == "number" or ReleaseConfig.StudioPreview) then
		return nil
	end

	return toUnix(v2) -- inferred equivalent call
end

function ReleaseConfig.ServerReleaseTime(p, p2)
	if isStudio then
		if type(ReleaseConfig.StudioTestReleaseIn) == "number" then
			return p2 + ReleaseConfig.StudioTestReleaseIn
		end

		if ReleaseConfig.StudioPreview then
			return 0
		end
	end

	return ReleaseConfig.ScheduledTime(p)
end

function ReleaseConfig.TimeLeft(p)
	if ReleaseConfig.IsUnlocked(p) then
		return 0
	end

	local attribute = workspace:GetAttribute("ReleaseAt_" .. tostring(p))

	if type(attribute) == "number" then
		return (math.max(0, attribute - workspace:GetServerTimeNow()))
	end

	return nil
end

function ReleaseConfig.FormatTime(value)
	local v2 = math.max(0, (math.floor(value or 0)))
	local v3 = v2 // 86400
	local v4 = v2 % 86400 // 3600
	local v5 = v2 % 3600 // 60
	local v6 = v2 % 60

	if v3 > 0 then
		return string.format("%dd %dh %02dm", v3, v4, v5)
	end

	if v4 > 0 then
		return string.format("%d:%02d:%02d", v4, v5, v6)
	end

	return string.format("%d:%02d", v5, v6)
end

function ReleaseConfig.Filter(list)
	local result = {}

	for _, item in ipairs(list) do
		if ReleaseConfig.IsOn(item.Release) then
			table.insert(result, item)
		end
	end

	return result
end

function ReleaseConfig.FillUnlocked(list, list2)
	table.clear(list)

	for _, item in ipairs(list2) do
		if not ReleaseConfig.IsUnlocked(item.Release) then
			break
		end

		table.insert(list, item)
	end

	return list
end

local v2 = {}
local v3 = {}

function ReleaseConfig.OnChanged(p)
	table.insert(v2, p)
end

function ReleaseConfig.Refresh()
	for k in pairs(ReleaseConfig.Schedule) do
		local isUnlocked = ReleaseConfig.IsUnlocked(k)

		if v3[k] == isUnlocked then
			continue
		end

		v3[k] = isUnlocked

		for _, callback in ipairs(v2) do
			local success, result = pcall(callback, k, isUnlocked)

			if not success then
				warn("[ReleaseConfig] listener failed for " .. k .. ": " .. tostring(result))
			end
		end
	end
end

for k in pairs(ReleaseConfig.Schedule) do
	v3[k] = ReleaseConfig.IsUnlocked(k)
	workspace:GetAttributeChangedSignal("Unlocked_" .. k):Connect(ReleaseConfig.Refresh)
end

local v4 = nil
local v5 = {}

function ReleaseConfig.OnScheduleChanged(callback)
	table.insert(v5, callback)
end

function ReleaseConfig.IsScheduleLoaded()
	return v4 == nil or v4:IsLoaded()
end

if RunService:IsRunning() then
	local ReplicatedStorage = game:GetService("ReplicatedStorage")
	local Asserts = require(ReplicatedStorage.UserGenerated.Lang.Asserts)
	local FastFlags = require(ReplicatedStorage.UserGenerated.FastFlags)

	local tbl = Asserts.Table({
		Year = Asserts.Integer,
		Month = Asserts.Integer,
		Day = Asserts.Integer,
		Hour = Asserts.IntegerRange(0, 23),
		Minute = Asserts.IntegerRange(0, 59),
		UtcOffset = Asserts.Range(-12, 14)
	})

	local function isMoment(p) -- 1 equivalent call inferred from this helper
		return (pcall(function()
			local _ = toUnix(tbl(p)) -- inferred equivalent call
		end))
	end

	local clone = table.clone(ReleaseConfig.Schedule)
	v4 = FastFlags.Replicated("Game.Release.Schedule", Asserts.Map(Asserts.String, Asserts.AnyTable), clone)

	local function applySchedule()
		local v6 = v4:Get()

		for k in pairs(v6) do
			if clone[k] == nil then
				warn(`[ReleaseConfig] Game.Release.Schedule: {k} is not in ReleaseConfig.Schedule`)
			end
		end

		for k, v7 in pairs(clone) do
			local v8 = v6[k]

			if v8 == nil then
				ReleaseConfig.Schedule[k] = v7
			elseif isMoment(v8) then -- inferred equivalent call
				ReleaseConfig.Schedule[k] = v8
			else
				warn(`[ReleaseConfig] Game.Release.Schedule: {k} is not a real moment, it stays as it was`)
			end
		end
	end

	applySchedule()
	v4.Changed:Connect(function()
		applySchedule()

		for _, callback in ipairs(v5) do
			task.spawn(callback)
		end
	end)
end

if RunService:IsServer() and RunService:IsRunning() then
	ReleaseConfig.IsDevServer()
end

return ReleaseConfig