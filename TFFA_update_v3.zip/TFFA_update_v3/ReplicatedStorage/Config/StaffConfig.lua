-- StaffConfig: pengaturan role staff (Developer / Admin / Content Creator) dan hak aksesnya.
-- Letak di Studio: ReplicatedStorage > Config > StaffConfig (ModuleScript)

local StaffConfig = {}

-- Developer = owner game, maksimal 2 orang, hanya bisa diubah lewat file ini.
-- Daftar yang sama dipakai panel DEV (ReleaseConfig.DevServer.Owners).
StaffConfig.MaxDevelopers = 2
StaffConfig.Developers = {
	10522335269, -- Owner 1
	8663872118, -- Owner 2
}

StaffConfig.DeveloperMap = {}
for index, id in ipairs(StaffConfig.Developers) do
	if index > StaffConfig.MaxDevelopers then
		break
	end
	StaffConfig.DeveloperMap[id] = "Developer " .. index
end

-- Di Roblox Studio semua pemain dianggap Developer supaya panel dan nametag gampang dites.
StaffConfig.StudioEveryoneIsDeveloper = true

-- Admin dan Content Creator disimpan di DataStore ini, lalu disinkronkan ke semua server.
StaffConfig.DataStoreName = "TFFA_StaffRoles_v1"
StaffConfig.DataStoreKey = "Roles"
StaffConfig.MessagingTopic = "StaffRolesChanged"

-- Attribute pada Player tempat server menyimpan role (otomatis terbaca juga oleh client).
StaffConfig.Attribute = "StaffRole"

-- Order kecil = tingkat lebih tinggi.
-- Panel = true berarti boleh memakai panel STAFF (F3) dan konsol perintah (F2).
StaffConfig.Roles = {
	Developer = {
		Order = 1,
		Label = "DEVELOPER",
		Color = Color3.fromRGB(255, 170, 40),
		Panel = true,
	},
	Admin = {
		Order = 2,
		Label = "ADMIN",
		Color = Color3.fromRGB(255, 70, 110),
		Panel = true,
	},
	ContentCreator = {
		Order = 3,
		Label = "CONTENT CREATOR",
		Color = Color3.fromRGB(190, 90, 255),
		Panel = false, -- hanya nametag, tanpa akses perintah
	},
}

-- Perintah konsol (F2) yang boleh dijalankan Admin = hanya yang non-economy.
-- Perintah lain (give, set, take, boost, setrole, dll) hanya untuk Developer.
StaffConfig.AdminCommands = {
	announce = true,
	kick = true,
	ban = true,
	unban = true,
	kill = true,
	respawn = true,
	teleport = true,
	uptime = true,
	version = true,
	stafflist = true,
	help = true,
	history = true,
	clear = true,
	echo = true,
}

-- Aksi di panel STAFF: role minimal yang boleh. "Admin" = Admin dan Developer, "Developer" = Developer saja.
StaffConfig.PanelActions = {
	-- non-economy (Admin dan Developer)
	announce = "Admin",
	kick = "Admin",
	ban = "Admin",
	unban = "Admin",
	mute = "Admin",
	unmute = "Admin",
	slap = "Admin",
	freeze = "Admin",
	unfreeze = "Admin",
	kill = "Admin",
	respawn = "Admin",
	bring = "Admin",
	tpto = "Admin",
	setstreamer = "Admin", -- menjadikan pemain Content Creator (streamer) atau mencabutnya
	poll_start = "Admin",
	poll_stop = "Admin",
	stafflist = "Admin",
	-- economy dan pengaturan penuh (Developer saja)
	boost = "Developer",
	cancelboost = "Developer",
	give_money = "Developer",
	give_superthrows = "Developer",
	abuse_start = "Developer",
	abuse_stop = "Developer",
	setrole = "Developer",
}

-- Tab di panel STAFF dan role minimal untuk melihatnya.
StaffConfig.PanelTabs = {
	{ Id = "players", Label = "Players", Min = "Admin" },
	{ Id = "announce", Label = "Announce", Min = "Admin" },
	{ Id = "poll", Label = "Poll", Min = "Admin" },
	{ Id = "boosts", Label = "Boosts", Min = "Developer" },
	{ Id = "event", Label = "Event", Min = "Developer" },
	{ Id = "staff", Label = "Staff", Min = "Developer" },
}

StaffConfig.Panel = {
	Key = Enum.KeyCode.F3,
	ButtonText = "STAFF",
	ButtonPosition = UDim2.new(0, 10, 0.5, -20), -- tombol buka panel (untuk HP juga)
}

StaffConfig.Poll = { MaxOptions = 4, MinSeconds = 10, MaxSeconds = 600, MaxTextLength = 120 }
StaffConfig.Announce = { MaxLength = 200 }

-- Tampilan nametag di atas kepala. Kalau menimpa nama bawaan Roblox, naikkan StudsOffset.
StaffConfig.Nametag = {
	StudsOffset = Vector3.new(0, 3.2, 0),
	MaxDistance = 90,
	TextSize = 14,
}

-- Apakah role ini sedikitnya setingkat minRole?
function StaffConfig.RoleAtLeast(role, minRole)
	local def = role and StaffConfig.Roles[role]
	local minDef = minRole and StaffConfig.Roles[minRole]
	if not def or not minDef then
		return false
	end
	return def.Order <= minDef.Order
end

-- Apakah role ini boleh menjalankan perintah konsol (F2) ini?
function StaffConfig.CanRun(role, commandName)
	local def = role and StaffConfig.Roles[role]
	if not def or not def.Panel then
		return false
	end

	if role == "Developer" then
		return true
	end

	return StaffConfig.AdminCommands[string.lower(commandName)] == true
end

-- Apakah role ini boleh melakukan aksi panel ini?
function StaffConfig.CanDo(role, action)
	local def = role and StaffConfig.Roles[role]
	if not def or not def.Panel then
		return false
	end
	return StaffConfig.RoleAtLeast(role, StaffConfig.PanelActions[action])
end

return StaffConfig
