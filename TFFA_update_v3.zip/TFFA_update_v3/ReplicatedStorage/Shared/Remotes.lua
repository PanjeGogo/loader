
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Remotes = {}

Remotes.Functions = {
	"Throw_Start",
	"Throw_Resolve",
	"Throw_Complete",
	"Throw_Cancel",
	"Throw_UseSuper",
	"Training_Start",
	"Training_Stop",
	"Training_TapBonus",
	"Shop_Buy",
	"Shop_Equip",
	"Stand_Upgrade",
	"Plot_PlaceAnimal",
	"Plot_PickUpAnimal",
	"Plot_SellAnimal",
	"Player_SetThrowPower",
	"Plot_UpgradeFence",
	"Plot_EquipAnimal",
	"Plot_EquipBest",
	"Player_SetSetting",
	"Animations_Get",
	"Shop_Prompt",
	"Shop_ClaimFree",
	"Egg_Place",
	"Gift_Request",
	"Gift_Respond",
	"Gift_Cancel",
	"Offline_Claim",
	"Plot_SellAll",
	"Sell_Protected",
	"Dev_Action",
	"StaffPanel_Action",
	"RingRush_Begin",
	"RingRush_Report",
	"RingRush_End",
	"RingRush_Learned"
}

Remotes.Events = {
	"Notify",
	"Effect",
	"Shop_Reward",
	"Shop_Announce",
	"Gift_Update",
	"Training_Bonus",
	"Throw_SuperGranted",
	"Shop_PromptClosed",
	"Shop_PackOffer",
	"Release_Seen",
	"Rollout_Report",
	"Event_Asked",
	"AdminAbuse_Vote",
	"AdminAbuse_VoteState",
	"AdminAbuse_Gift",
	"AFK_Rejoin",
	"Throw_MeterStarted",
	"Announce",
	"StaffPoll_State",
	"StaffPoll_Vote",
	"RingRush_Reward"
}

local function getFolder()
	if not RunService:IsServer() then
		return ReplicatedStorage:WaitForChild("Remotes")
	end

	local remotes = ReplicatedStorage:FindFirstChild("Remotes")

	if not remotes then
		remotes = Instance.new("Folder")
		remotes.Name = "Remotes"
		remotes.Parent = ReplicatedStorage
	end

	return remotes
end

function Remotes.Init()
	local remotes

	if RunService:IsServer() then
		remotes = ReplicatedStorage:FindFirstChild("Remotes")

		if not remotes then
			remotes = Instance.new("Folder")
			remotes.Name = "Remotes"
			remotes.Parent = ReplicatedStorage
		end
	else
		remotes = ReplicatedStorage:WaitForChild("Remotes")
	end

	for _, childName in ipairs(Remotes.Functions) do
		if remotes:FindFirstChild(childName) then
			continue
		end

		local remoteFunction = Instance.new("RemoteFunction")
		remoteFunction.Name = childName
		remoteFunction.Parent = remotes
	end

	for _, childName in ipairs(Remotes.Events) do
		if remotes:FindFirstChild(childName) then
			continue
		end

		local remoteEvent = Instance.new("RemoteEvent")
		remoteEvent.Name = childName
		remoteEvent.Parent = remotes
	end
end

function Remotes.Function(childName)
	local remotes

	if RunService:IsServer() then
		remotes = ReplicatedStorage:FindFirstChild("Remotes")

		if not remotes then
			remotes = Instance.new("Folder")
			remotes.Name = "Remotes"
			remotes.Parent = ReplicatedStorage
		end
	else
		remotes = ReplicatedStorage:WaitForChild("Remotes")
	end

	if RunService:IsServer() then
		return remotes:FindFirstChild(childName)
	end

	return remotes:WaitForChild(childName)
end

function Remotes.Event(p)
	return Remotes.Function(p)
end

function Remotes.Invoke(p, ...)
	local v = Remotes.Function(p)
	local success, result = pcall(v.InvokeServer, v, ...)

	if not success then
		warn("[Remotes] " .. p .. " failed: " .. tostring(result))
		return { Ok = false, Reason = "Error" }
	end

	if type(result) == "table" then
		return result
	end

	return { Ok = false, Reason = "BadResponse" }
end

return Remotes