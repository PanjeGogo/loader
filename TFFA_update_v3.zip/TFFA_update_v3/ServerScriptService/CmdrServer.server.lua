-- Serveur Cmdr (panneau admin : F2 ou /cmdr). Réutilise les modules partagés de ReplicatedStorage.CmdrClient
-- et fournit les implémentations serveur des commandes du jeu.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MessagingService = game:GetService("MessagingService")

local CmdrClient = ReplicatedStorage:WaitForChild("CmdrClient")
local Shared = CmdrClient:WaitForChild("Shared")

local Util = require(Shared.Util)
local makeRegistry = require(Shared.Registry)
local makeDispatcher = require(Shared.Dispatcher)

local Config = ReplicatedStorage.Config
local LevelConfig = require(Config.LevelConfig)
local FoodsConfig = require(Config.FoodsConfig)
local StandsConfig = require(Config.StandsConfig)
local FenceConfig = require(Config.FenceConfig)
local EggsConfig = require(Config.EggsConfig)
local MonetizationConfig = require(Config.MonetizationConfig)
local AdminAbuseConfig = require(Config.AdminAbuseConfig)
local NumberFormat = require(ReplicatedStorage.Shared.NumberFormat)
local Remotes = require(ReplicatedStorage.Shared.Remotes)

local Server = script.Parent:WaitForChild("Server")
local Data = require(Server.Data)
local AnimalService = require(Server.AnimalService)
local PlotService = require(Server.PlotService)
local Gameplay = require(Server.GameplayService)
local Staff = require(Server.StaffService)
local StaffPanel = require(Server.StaffPanelService)
local StaffConfig = require(Config.StaffConfig)

local Cmdr = {
	Util = Util,
	_replicatedRoot = CmdrClient,
	_remoteEvent = CmdrClient:WaitForChild("CmdrEvent"),
	_remoteFunction = CmdrClient:WaitForChild("CmdrFunction"),
	_events = {},
}
Cmdr.Registry = makeRegistry(Cmdr)
Cmdr.Dispatcher = makeDispatcher(Cmdr)

---------------------------------------------------------------- utilitaires
local function each(players, fn)
	local ok, msg = {}, {}
	for _, p in ipairs(players or {}) do
		if not Data.Get(p) then
			table.insert(msg, p.Name .. ": données pas encore chargées")
		else
			local r = fn(p, Data.Get(p))
			if r then table.insert(msg, p.Name .. ": " .. r) else table.insert(ok, p.Name) end
		end
	end
	if #ok > 0 then table.insert(msg, 1, "OK pour " .. table.concat(ok, ", ") .. ".") end
	return #msg > 0 and table.concat(msg, "\n") or "Aucun joueur."
end

local function now() return workspace:GetServerTimeNow() end

local BOOST_ATTR = { luck = "AdminLuck", money = "AdminMoney", training = "AdminTraining" }
local BOOST_MAX = {
	luck = MonetizationConfig.ServerLuck.MaxAdminBoost,
	money = AdminAbuseConfig.CommandBoosts.money.Max,
	training = AdminAbuseConfig.CommandBoosts.training.Max,
}

local function applyBoost(kind, mult, duration)
	local attr = BOOST_ATTR[kind]
	if mult <= 1 then
		workspace:SetAttribute(attr, nil)
		workspace:SetAttribute(attr .. "End", nil)
		return
	end
	local cur = workspace:GetAttribute(attr) or 1
	local ends = workspace:GetAttribute(attr .. "End") or 0
	if ends <= now() then cur = 1 end
	local value = cur > 1 and math.min(cur + mult, BOOST_MAX[kind]) or math.min(mult, BOOST_MAX[kind])
	workspace:SetAttribute(attr, value)
	workspace:SetAttribute(attr .. "End", math.max(ends, now()) + (duration or 900))
end

local function cancelBoost(kind)
	for k, attr in pairs(BOOST_ATTR) do
		if kind == "all" or kind == k then
			workspace:SetAttribute(attr, nil)
			workspace:SetAttribute(attr .. "End", nil)
		end
	end
end

local function announce(name, userId, text)
	Remotes.Event("Announce"):FireAllClients({ Name = name, UserId = userId, Text = text, Seconds = 8 })
end

-- portée "global" : relayé aux autres serveurs
local TOPIC = "AdminCommands"
local function runAction(a)
	if a.Kind == "Boost" then applyBoost(a.Boost, a.Mult, a.Duration)
	elseif a.Kind == "CancelBoost" then cancelBoost(a.Boost)
	elseif a.Kind == "Announce" then announce(a.Name, a.UserId, a.Text) end
end
local function dispatch(scope, action)
	runAction(action)
	if scope == "global" then
		action.JobId = game.JobId
		local ok, err = pcall(function() MessagingService:PublishAsync(TOPIC, action) end)
		if not ok then return " (les autres serveurs n'ont pas pu être prévenus : " .. tostring(err) .. ")" end
	end
	return ""
end
pcall(function()
	MessagingService:SubscribeAsync(TOPIC, function(msg)
		local a = msg.Data
		if type(a) == "table" and a.JobId ~= game.JobId then runAction(a) end
	end)
end)

local function setPass(player, key, owned)
	local pass = MonetizationConfig.Passes[key]
	Data.Set(player, { "Passes", key }, owned or nil)
	Gameplay.ApplyPasses(player)
end

---------------------------------------------------------------- commandes
local Impl = {}

Impl.give = function(ctx, players, kind, a, b, c)
	return each(players, function(p, d)
		if kind == "money" then Data.AddMoney(p, a)
		elseif kind == "food" then
			for _, i in ipairs(a) do Data.Set(p, { "OwnedFoods", tostring(i) }, true) end
		elseif kind == "animal" then
			AnimalService.Add(p, { ModelName = a, Mutation = b, Size = c or 1 })
			PlotService.QueueTools(p)
		elseif kind == "egg" then
			Data.Set(p, { "Eggs", a }, (d.Eggs[a] or 0) + (b or 1))
			PlotService.QueueTools(p)
		elseif kind == "superthrows" then
			Data.Set(p, "SuperThrows", (d.SuperThrows or 0) + a)
		elseif kind == "pass" then setPass(p, a, true)
		elseif kind == "product" then
			local product = MonetizationConfig.Products[a]
			if not product then return "produit inconnu" end
			Gameplay.Grant(p, product)
			Remotes.Event("Shop_Reward"):FireClient(p, { Key = product.Key, Product = product.Key, Grant = product.Grant })
		elseif kind == "levels" then
			Data.Set(p, "Level", math.min(LevelConfig.MaxLevel, (d.Level or 1) + a))
			Data.Set(p, "Xp", 0)
		else return "type inconnu" end
		return nil
	end)
end

Impl.set = function(ctx, players, kind, a)
	return each(players, function(p, d)
		if kind == "money" then Data.Set(p, "Money", a)
		elseif kind == "level" then
			Data.Set(p, "Level", math.clamp(a, 1, LevelConfig.MaxLevel))
			Data.Set(p, "Xp", 0)
		elseif kind == "bar" then
			Data.Set(p, "Stand", math.clamp(a, 0, StandsConfig.Count()))
			PlotService.BuildStand(p)
		elseif kind == "fence" then
			Data.Set(p, "FenceLevel", math.clamp(a, 0, FenceConfig.MaxLevel()))
			PlotService.ApplyFence(p)
			PlotService.RefreshIncomes(p)
		elseif kind == "superthrows" then Data.Set(p, "SuperThrows", a)
		else return "type inconnu" end
		return nil
	end)
end

Impl.take = function(ctx, players, kind, a, b)
	return each(players, function(p, d)
		if kind == "money" then Data.Set(p, "Money", math.max(0, (d.Money or 0) - a))
		elseif kind == "food" then
			for _, i in ipairs(a) do
				if i ~= 1 then Data.Set(p, { "OwnedFoods", tostring(i) }, nil) end
			end
			if not d.OwnedFoods[tostring(d.EquippedFood)] then Data.Set(p, "EquippedFood", 1) end
		elseif kind == "egg" then
			local n = b and math.max(0, (d.Eggs[a] or 0) - b) or 0
			Data.Set(p, { "Eggs", a }, n)
			PlotService.QueueTools(p)
		elseif kind == "superthrows" then
			Data.Set(p, "SuperThrows", math.max(0, (d.SuperThrows or 0) - a))
		elseif kind == "pass" then setPass(p, a, false)
		else return "type inconnu" end
		return nil
	end)
end

Impl.inspect = function(ctx, player)
	local d = Data.Get(player)
	if not d then return player.Name .. " : données pas encore chargées." end
	local foods, animals, placed, eggs, passes = 0, 0, 0, {}, {}
	for _ in pairs(d.OwnedFoods) do foods += 1 end
	for _, e in pairs(d.Animals) do animals += 1 if e.Placed then placed += 1 end end
	for k, n in pairs(d.Eggs) do if n > 0 then table.insert(eggs, k .. " x" .. n) end end
	for k, v in pairs(d.Passes or {}) do if v then table.insert(passes, k) end end
	local stand = StandsConfig.GetAny(d.Stand or 0)
	return table.concat({
		player.Name .. " (" .. player.UserId .. ")",
		"Argent : " .. NumberFormat.Money(d.Money or 0) .. "  |  Revenu : " .. NumberFormat.PerSecond(player:GetAttribute("IncomeRate") or 0),
		"Niveau : " .. (d.Level or 1) .. "  |  Barre : " .. (stand and stand.Name or "aucune") .. "  |  Clôture : " .. (d.FenceLevel or 0),
		"Nourritures : " .. foods .. " (équipée #" .. tostring(d.EquippedFood) .. ")  |  Lancers : " .. (d.Throws or 0) .. "  |  Super lancers : " .. (d.SuperThrows or 0),
		"Animaux : " .. animals .. " (" .. placed .. " sur le plot)",
		"Œufs : " .. (#eggs > 0 and table.concat(eggs, ", ") or "aucun"),
		"Passes offerts : " .. (#passes > 0 and table.concat(passes, ", ") or "aucun"),
	}, "\n")
end

Impl.boost = function(ctx, scope, kind, mult, duration)
	local extra = dispatch(scope, { Kind = "Boost", Boost = kind, Mult = mult, Duration = duration })
	if mult <= 1 then return "Boosts " .. kind .. " arrêtés." .. extra end
	return "Boost " .. kind .. " : x" .. tostring(workspace:GetAttribute(BOOST_ATTR[kind])) .. " pendant " .. math.floor((duration or 900) / 60) .. " min." .. extra
end

Impl.cancelboost = function(ctx, scope, kind)
	return "Boosts arrêtés (" .. kind .. ")." .. dispatch(scope, { Kind = "CancelBoost", Boost = kind })
end

Impl.announce = function(ctx, scope, text)
	local ex = ctx.Executor
	return "Annonce envoyée." .. dispatch(scope, { Kind = "Announce", Name = ex.DisplayName, UserId = ex.UserId, Text = text })
end

Impl.announceben = function(ctx, scope, text)
	return "Annonce envoyée (Ben)." .. dispatch(scope, { Kind = "Announce", Name = "Ben", UserId = 0, Text = text })
end

Impl.forcenextanimal = function(ctx, player, animal)
	Gameplay.ForcedNext[player] = animal
	return "Le prochain lancer de " .. player.Name .. " donnera : " .. AnimalService.DisplayName(animal)
end

local function unavailable() return "Les événements en direct (Ring Rush) ne sont pas disponibles dans cette version." end
Impl.startevent = unavailable
Impl.cancelevent = unavailable
Impl.eventstage = unavailable
Impl.setdata = function() return "Commande réservée à la place de développement d'origine." end
Impl.abtest = function() return "Aucun test A/B actif dans ce jeu." end

-- commandes de base de Cmdr
Impl.kick = function(ctx, players, reason)
	for _, p in ipairs(players) do p:Kick(reason or "Expulsé par un admin.") end
	return "Expulsé : " .. #players .. " joueur(s)."
end
Impl.kill = function(ctx, players)
	for _, p in ipairs(players) do
		local h = p.Character and p.Character:FindFirstChildOfClass("Humanoid")
		if h then h.Health = 0 end
	end
	return "OK."
end
Impl.respawn = function(ctx, players)
	for _, p in ipairs(players) do p:LoadCharacter() end
	return "OK."
end
Impl.teleport = function(ctx, players, target)
	local cf
	if typeof(target) == "Instance" and target:IsA("Player") then
		cf = target.Character and target.Character:GetPivot()
	elseif typeof(target) == "Vector3" then
		cf = CFrame.new(target)
	end
	if not cf then return "Destination introuvable." end
	for _, p in ipairs(players) do
		if p.Character then p.Character:PivotTo(cf + Vector3.new(0, 3, 0)) end
	end
	return "Téléporté : " .. #players .. " joueur(s)."
end
Impl.uptime = function() return "Serveur en ligne depuis " .. math.floor(workspace.DistributedGameTime / 60) .. " min." end
Impl.version = function() return "Throw Food For Animals — serveur reconstruit" end

-- role staff: setrole hanya untuk Developer (dicek di BeforeRun), stafflist untuk Developer dan Admin
Impl.setrole = function(ctx, userId, role)
	local roleName = role ~= "None" and role or nil
	local _, message = Staff.SetRole(ctx.Executor, userId, roleName)
	return message
end

Impl.stafflist = function(ctx)
	local lines = {}
	for i, entry in ipairs(Staff.List()) do
		local def = StaffConfig.Roles[entry.Role]
		table.insert(lines, def.Label .. " - " .. Staff.NameOf(entry.UserId, i > 40) .. " (" .. entry.UserId .. ")")
	end
	return #lines > 0 and table.concat(lines, "\n") or "No staff yet."
end

-- panel STAFF (F3) memakai logika Impl yang sama untuk aksi economy (give, boost, dll)
StaffPanel.BindImpl(Impl)

---------------------------------------------------------------- enregistrement
Cmdr.Registry:RegisterTypesIn(CmdrClient:WaitForChild("Types"))

for _, moduleScript in ipairs(CmdrClient:WaitForChild("Commands"):GetChildren()) do
	if moduleScript:IsA("ModuleScript") then
		local ok, err = pcall(function()
			Cmdr.Registry:RegisterCommand(moduleScript, nil, function(def)
				local impl = Impl[string.lower(def.Name)]
				if impl and not def.ClientRun then
					def.Run = impl
				end
				return true
			end)
		end)
		if not ok then warn("[CmdrServer] " .. moduleScript.Name .. " : " .. tostring(err)) end
	end
end

Cmdr._remoteFunction.OnServerInvoke = function(player, text, options)
	if type(text) ~= "string" then return "Commande invalide." end
	options = type(options) == "table" and options or {}
	return Cmdr.Dispatcher:EvaluateAndRun(text, player, { Data = options.Data, IsHuman = true })
end

print("[CmdrServer] Panneau admin prêt (F2 ou /cmdr)")
