-- Point d'entrée du serveur
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
Remotes.Init()

Players.CharacterAutoLoads = true

local Server = script.Parent
local Data = require(Server.Data)
local PlotService = require(Server.PlotService)
local Gameplay = require(Server.GameplayService)
local World = require(Server.WorldService)
local Staff = require(Server.StaffService)
local StaffPanel = require(Server.StaffPanelService)
local Pokemon = require(Server.PokemonService)

-- reset des plots au démarrage
for _, plot in ipairs(workspace:WaitForChild("Plots"):GetChildren()) do
	plot:SetAttribute("OwnerUserId", 0)
	plot:SetAttribute("PlotIndex", tonumber(plot.Name))
	plot:SetAttribute("FenceLevel", 0)
	plot:SetAttribute("FenceGrow", 0)
end

Pokemon.Start()
World.Start()
PlotService.Start()
Gameplay.Start()
Staff.Start()
StaffPanel.Start()
Data.Start()

print("[Server] Démarré")
