-- ModerationService (server): kick, ban, unban, mute, slap, freeze, announce, dan polling.
-- Izin sudah dicek oleh StaffPanelService, file ini hanya menjalankan aksinya.
-- Letak di Studio: ServerScriptService > Server > ModerationService (ModuleScript)

local Players = game:GetService("Players")
local TextService = game:GetService("TextService")
local TextChatService = game:GetService("TextChatService")
local MessagingService = game:GetService("MessagingService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)

local Moderation = {}

local ANNOUNCE_TOPIC = "AdminCommands" -- sama dengan CmdrServer, supaya server lain ikut menampilkan
local POLL_STATE = "StaffPoll_State"
local POLL_VOTE = "StaffPoll_Vote"

---------------------------------------------------------------- util
-- Teks yang diketik staff dan tampil ke pemain lain tetap difilter Roblox.
function Moderation.Filter(text, userId)
	local ok, result = pcall(function()
		local filtered = TextService:FilterStringAsync(text, userId, Enum.TextFilterContext.PublicChat)
		return filtered:GetNonChatStringForBroadcastAsync()
	end)
	if ok and type(result) == "string" then
		return result
	end
	return nil
end

local function characterParts(player)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	return character, root, humanoid
end

---------------------------------------------------------------- kick, ban, unban
function Moderation.Kick(actor, target, reason)
	local name = target.Name
	if reason == "" then
		reason = "You were kicked by staff."
	end
	target:Kick(reason)
	return true, name .. " was kicked."
end

function Moderation.Ban(actor, userId, name, reason, days)
	local duration = -1 -- permanen
	if days and days > 0 then
		duration = math.floor(days * 86400)
	end

	local displayReason = reason ~= "" and reason or "You have been banned."
	local ok, err = pcall(function()
		Players:BanAsync({
			UserIds = { userId },
			Duration = duration,
			DisplayReason = displayReason,
			PrivateReason = "Banned by " .. actor.Name .. " (" .. actor.UserId .. "): " .. reason,
			ExcludeAltAccounts = false,
			ApplyToUniverse = true,
		})
	end)
	if not ok then
		return false, "Ban failed: " .. tostring(err)
	end

	if duration == -1 then
		return true, name .. " was banned permanently."
	end
	return true, name .. " was banned for " .. days .. " day(s)."
end

function Moderation.Unban(actor, userId, name)
	local ok, err = pcall(function()
		Players:UnbanAsync({
			UserIds = { userId },
			ApplyToUniverse = true,
		})
	end)
	if not ok then
		return false, "Unban failed: " .. tostring(err)
	end
	return true, name .. " was unbanned."
end

---------------------------------------------------------------- mute / unmute
local muted = {}

local function hookChannel(channel)
	if not channel:IsA("TextChannel") then
		return
	end
	channel.ShouldDeliverCallback = function(message, target)
		local source = message.TextSource
		if source and muted[source.UserId] then
			return target.UserId == source.UserId -- pengirim tetap melihat pesannya sendiri
		end
		return true
	end
end

local function hookChat()
	task.spawn(function()
		pcall(function()
			local channels = TextChatService:WaitForChild("TextChannels", 15)
			if not channels then
				return
			end
			for _, channel in ipairs(channels:GetChildren()) do
				hookChannel(channel)
			end
			channels.ChildAdded:Connect(hookChannel)
		end)
	end)
end

local function chatReady()
	return TextChatService.ChatVersion == Enum.ChatVersion.TextChatService
end

function Moderation.Mute(actor, target)
	muted[target.UserId] = true
	target:SetAttribute("StaffMuted", true)
	if not chatReady() then
		return true, target.Name .. " muted (note: this game does not use TextChatService, so the chat is not blocked)."
	end
	return true, target.Name .. " was muted."
end

function Moderation.Unmute(actor, target)
	muted[target.UserId] = nil
	target:SetAttribute("StaffMuted", nil)
	return true, target.Name .. " was unmuted."
end

---------------------------------------------------------------- slap, freeze, kill, respawn, teleport
function Moderation.Slap(actor, target)
	local _, root, humanoid = characterParts(target)
	if not root or not humanoid then
		return false, target.Name .. " has no character right now."
	end
	root.AssemblyLinearVelocity = Vector3.new(math.random(-40, 40), 90, math.random(-40, 40))
	humanoid:TakeDamage(10)
	return true, target.Name .. " got slapped."
end

local function freezeCharacter(target)
	local _, root = characterParts(target)
	if not root then
		return false
	end
	if target:GetAttribute("StaffFrozenWasAnchored") == nil then
		target:SetAttribute("StaffFrozenWasAnchored", root.Anchored)
	end
	root.Anchored = true
	return true
end

function Moderation.Freeze(actor, target)
	target:SetAttribute("StaffFrozen", true)
	if not freezeCharacter(target) then
		return true, target.Name .. " will be frozen when the character spawns."
	end
	return true, target.Name .. " was frozen."
end

function Moderation.Unfreeze(actor, target)
	target:SetAttribute("StaffFrozen", nil)
	local _, root = characterParts(target)
	local wasAnchored = target:GetAttribute("StaffFrozenWasAnchored")
	target:SetAttribute("StaffFrozenWasAnchored", nil)
	if root then
		root.Anchored = wasAnchored == true
	end
	return true, target.Name .. " was unfrozen."
end

function Moderation.Kill(actor, target)
	local _, _, humanoid = characterParts(target)
	if not humanoid then
		return false, target.Name .. " has no character right now."
	end
	humanoid.Health = 0
	return true, target.Name .. " was killed."
end

function Moderation.Respawn(actor, target)
	target:LoadCharacter()
	return true, target.Name .. " was respawned."
end

function Moderation.Bring(actor, target)
	local actorCharacter = characterParts(actor)
	local targetCharacter = characterParts(target)
	if not actorCharacter or not targetCharacter then
		return false, "Both characters must be spawned."
	end
	targetCharacter:PivotTo(actorCharacter:GetPivot() * CFrame.new(0, 0, -5))
	return true, target.Name .. " was brought to you."
end

function Moderation.TeleportTo(actor, target)
	local actorCharacter = characterParts(actor)
	local targetCharacter = characterParts(target)
	if not actorCharacter or not targetCharacter then
		return false, "Both characters must be spawned."
	end
	actorCharacter:PivotTo(targetCharacter:GetPivot() * CFrame.new(0, 0, 5))
	return true, "Teleported to " .. target.Name .. "."
end

---------------------------------------------------------------- announce
function Moderation.Announce(actor, text, scope)
	local clean = Moderation.Filter(text, actor.UserId)
	if not clean then
		return false, "The text could not be filtered, try again."
	end

	Remotes.Event("Announce"):FireAllClients({
		Name = actor.DisplayName,
		UserId = actor.UserId,
		Text = clean,
		Seconds = 8,
	})

	if scope == "global" then
		local ok, err = pcall(function()
			MessagingService:PublishAsync(ANNOUNCE_TOPIC, {
				Kind = "Announce",
				Name = actor.DisplayName,
				UserId = actor.UserId,
				Text = clean,
				JobId = game.JobId,
			})
		end)
		if not ok then
			return true, "Announcement sent here, but other servers could not be reached: " .. tostring(err)
		end
		return true, "Announcement sent to all servers."
	end

	return true, "Announcement sent."
end

---------------------------------------------------------------- polling (per server)
local poll = nil
local pollCounter = 0
local pollDirty = false

local function pollPayload()
	if not poll then
		return nil
	end
	return {
		Id = poll.Id,
		Question = poll.Question,
		Options = poll.Options,
		Counts = poll.Counts,
		EndsAt = poll.EndsAt,
		By = poll.By,
		Closed = poll.Closed,
	}
end

local function broadcastPoll()
	Remotes.Event(POLL_STATE):FireAllClients(pollPayload())
end

local function recount()
	local counts = {}
	for index = 1, #poll.Options do
		counts[index] = 0
	end
	for _, choice in pairs(poll.Votes) do
		counts[choice] = counts[choice] + 1
	end
	poll.Counts = counts
end

local function closePoll()
	if not poll or poll.Closed then
		return
	end
	poll.Closed = true
	broadcastPoll()

	local closedId = poll.Id
	task.delay(30, function()
		if poll and poll.Id == closedId then
			poll = nil
			broadcastPoll()
		end
	end)
end

function Moderation.StartPoll(actor, question, options, seconds)
	if poll and not poll.Closed then
		return false, "A poll is already running. Stop it first."
	end

	local cleanQuestion = Moderation.Filter(question, actor.UserId)
	if not cleanQuestion then
		return false, "The question could not be filtered, try again."
	end

	local cleanOptions = {}
	for _, option in ipairs(options) do
		local clean = Moderation.Filter(option, actor.UserId)
		if not clean then
			return false, "An option could not be filtered, try again."
		end
		table.insert(cleanOptions, clean)
	end

	pollCounter = pollCounter + 1
	poll = {
		Id = pollCounter,
		Question = cleanQuestion,
		Options = cleanOptions,
		Votes = {},
		Counts = {},
		EndsAt = workspace:GetServerTimeNow() + seconds,
		By = actor.DisplayName,
		Closed = false,
	}
	recount()
	broadcastPoll()

	local startedId = poll.Id
	task.delay(seconds, function()
		if poll and poll.Id == startedId then
			closePoll()
		end
	end)

	return true, "Poll started for " .. seconds .. " seconds."
end

function Moderation.StopPoll(actor)
	if not poll or poll.Closed then
		return false, "There is no running poll."
	end
	closePoll()
	return true, "Poll stopped."
end

---------------------------------------------------------------- start
function Moderation.Start()
	hookChat()

	Remotes.Event(POLL_VOTE).OnServerEvent:Connect(function(player, id, choice)
		if id == 0 then -- client baru siap dan minta status polling saat ini
			Remotes.Event(POLL_STATE):FireClient(player, pollPayload())
			return
		end

		if not poll or poll.Closed or poll.Id ~= id then
			return
		end
		if type(choice) ~= "number" or choice % 1 ~= 0 or choice < 1 or choice > #poll.Options then
			return
		end

		poll.Votes[player.UserId] = choice
		recount()

		if not pollDirty then -- gabungkan banyak suara jadi satu pembaruan
			pollDirty = true
			task.delay(0.4, function()
				pollDirty = false
				if poll then
					broadcastPoll()
				end
			end)
		end
	end)

	-- pemain yang di-freeze tetap beku setelah respawn
	local function track(player)
		player.CharacterAdded:Connect(function()
			if player:GetAttribute("StaffFrozen") then
				task.wait(1)
				freezeCharacter(player)
			end
		end)
	end
	Players.PlayerAdded:Connect(track)
	for _, player in ipairs(Players:GetPlayers()) do
		track(player)
	end

	Players.PlayerRemoving:Connect(function(player)
		muted[player.UserId] = nil
		if poll then
			poll.Votes[player.UserId] = nil
		end
	end)
end

return Moderation
