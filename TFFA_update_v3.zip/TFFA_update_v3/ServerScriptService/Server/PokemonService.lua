-- PokemonService (server): mengganti model hewan dengan model Pokémon dari Creator Store.
-- Aset dimuat lewat InsertService saat server menyala, dibersihkan (semua script dan efek dibuang),
-- disamakan ukurannya dengan model hewan aslinya, lalu ditaruh di ReplicatedStorage.PokemonAnimals.
-- Hewan yang aset-nya gagal dimuat tetap memakai model aslinya.
-- Letak di Studio: ServerScriptService > Server > PokemonService (ModuleScript)

local InsertService = game:GetService("InsertService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PokemonConfig = require(ReplicatedStorage.Config.PokemonConfig)
local AnimalTemplates = require(ReplicatedStorage.Shared.AnimalTemplates)

local PokemonService = {}

-- Isi aset buatan orang lain tidak dipercaya: semua yang bukan tampilan dibuang.
local REMOVE_CLASSES = {
	"LuaSourceContainer", -- Script, LocalScript, ModuleScript
	"Sound",
	"SoundGroup",
	"Sky",
	"Atmosphere",
	"PostEffect",
	"Humanoid",
	"Tool",
	"LayerCollector", -- ScreenGui, BillboardGui, SurfaceGui
	"ParticleEmitter",
	"Fire",
	"Smoke",
	"Sparkles",
	"Trail",
	"Beam",
	"Light", -- PointLight, SpotLight, SurfaceLight
	"ForceField",
	"ClickDetector",
	"ProximityPrompt",
	"BodyMover",
	"RemoteEvent",
	"RemoteFunction",
	"BindableEvent",
	"BindableFunction",
}

local function sanitize(root)
	for _, descendant in ipairs(root:GetDescendants()) do
		for _, className in ipairs(REMOVE_CLASSES) do
			if descendant:IsA(className) then
				descendant:Destroy()
				break
			end
		end
	end
end

local function countParts(model)
	local count = 0
	for _, descendant in ipairs(model:GetDescendants()) do
		if descendant:IsA("BasePart") then
			count = count + 1
		end
	end
	return count
end

-- Aset bisa berisi beberapa model (paket). Ambil yang part-nya paling banyak.
local function pickModel(container)
	local best = nil
	local bestCount = 0
	for _, child in ipairs(container:GetChildren()) do
		if child:IsA("Model") then
			local parts = countParts(child)
			if parts > bestCount then
				best, bestCount = child, parts
			end
		end
	end
	if best then
		return best
	end

	-- aset berisi part langsung tanpa Model
	local wrapper = Instance.new("Model")
	for _, child in ipairs(container:GetChildren()) do
		if child:IsA("BasePart") then
			child.Parent = wrapper
		end
	end
	if countParts(wrapper) > 0 then
		return wrapper
	end
	wrapper:Destroy()
	return nil
end

local function longestSide(model)
	local size = model:GetExtentsSize()
	return math.max(size.X, size.Y, size.Z)
end

local function loadAsset(assetId)
	local container = nil
	local done = false

	task.spawn(function()
		local ok, result = pcall(function()
			return InsertService:LoadAsset(assetId)
		end)
		if ok then
			container = result
		end
		done = true
	end)

	local startedAt = os.clock()
	while not done and os.clock() - startedAt < PokemonConfig.LoadTimeout do
		task.wait(0.1)
	end

	return container
end

local function normalize(model, modelName, entry, originals)
	model.Name = modelName

	-- part terbesar jadi PrimaryPart; semua part dikunci (AnimalUtil juga mengunci saat dipakai)
	local biggest = nil
	local biggestVolume = -1
	for _, descendant in ipairs(model:GetDescendants()) do
		if descendant:IsA("BasePart") then
			descendant.Anchored = true
			descendant.CanCollide = false
			descendant.CanTouch = false
			descendant.Massless = true
			local volume = descendant.Size.X * descendant.Size.Y * descendant.Size.Z
			if volume > biggestVolume then
				biggest, biggestVolume = descendant, volume
			end
		end
	end
	model.PrimaryPart = biggest

	local yaw = PokemonConfig.FaceFix[modelName]
	if yaw and yaw ~= 0 then
		model:PivotTo(model:GetPivot() * CFrame.Angles(0, math.rad(yaw), 0))
	end

	-- samakan ukuran dengan model hewan aslinya supaya pengaturan skala game tetap cocok
	local target = PokemonConfig.DefaultLongest
	local original = originals and originals:FindFirstChild(modelName)
	if original and original:IsA("Model") then
		local originalLongest = longestSide(original)
		if originalLongest > 0 then
			target = originalLongest
		end
	end

	local current = longestSide(model)
	if current > 0 then
		local factor = math.clamp(target / current, 0.001, 1000)
		model:ScaleTo(model:GetScale() * factor)
	end

	model:SetAttribute("PokemonName", entry.Pokemon)
	model:SetAttribute("PokemonDex", entry.Dex)
end

-- Mencoba aset satu per satu sampai ada yang berhasil. Hasil: assetId yang dipakai, atau nil.
local function buildAnimal(modelName, entry, folder, originals)
	for _, assetId in ipairs(entry.Assets) do
		local container = loadAsset(assetId)
		if container then
			local model = pickModel(container)
			if model then
				sanitize(model)
				local parts = countParts(model)
				if parts >= 1 and parts <= PokemonConfig.MaxParts and longestSide(model) > 0.01 then
					normalize(model, modelName, entry, originals)
					model:SetAttribute("PokemonAsset", assetId)
					model.Parent = folder
					container:Destroy()
					return assetId
				end
			end
			container:Destroy()
		end
	end
	return nil
end

function PokemonService.Start()
	if not PokemonConfig.Enabled then
		return
	end

	local folder = ReplicatedStorage:FindFirstChild(PokemonConfig.FolderName)
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = PokemonConfig.FolderName
		folder.Parent = ReplicatedStorage
	end

	-- AnimalTemplates.Get memakai fungsi ini lebih dulu; kalau hasilnya nil, model asli yang dipakai.
	local function install()
		AnimalTemplates.SetOverride(function(name)
			return folder:FindFirstChild(name)
		end)
	end
	install()

	task.spawn(function()
		local originals = ReplicatedStorage:WaitForChild("Animals", 30)

		local queue = {}
		for modelName, entry in pairs(PokemonConfig.Map) do
			if #entry.Assets > 0 then
				table.insert(queue, modelName)
			end
		end
		table.sort(queue)

		local nextIndex = 1
		local active = 0
		local loaded = 0
		local failed = {}

		local function worker()
			while true do
				local modelName = queue[nextIndex]
				nextIndex = nextIndex + 1
				if not modelName then
					break
				end

				local entry = PokemonConfig.Map[modelName]
				local ok, assetId = pcall(buildAnimal, modelName, entry, folder, originals)
				if ok and assetId then
					loaded = loaded + 1
				else
					table.insert(failed, modelName .. " (" .. entry.Pokemon .. ")")
				end
			end
			active = active - 1
		end

		for _ = 1, PokemonConfig.Workers do
			active = active + 1
			task.spawn(worker)
		end
		while active > 0 do
			task.wait(0.5)
		end

		folder:SetAttribute("Loaded", loaded)
		folder:SetAttribute("Ready", true)
		install() -- fungsi baru supaya AnimalTemplates.Changed menyala dan tampilan dimuat ulang

		print("[Pokemon] " .. loaded .. "/" .. #queue .. " model Pokémon dimuat.")
		if #failed > 0 then
			warn("[Pokemon] Gagal dimuat (memakai model hewan asli): " .. table.concat(failed, ", "))
		end
	end)
end

return PokemonService
