-- StaffPanelService (server): menerima aksi dari panel STAFF, mengecek izin di server,
-- lalu menjalankannya. Client tidak pernah dipercaya: role selalu dicek ulang di sini.
-- Letak di Studio: ServerScriptService > Server > StaffPanelService (ModuleScript)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local StaffConfig = require(ReplicatedStorage.Config.StaffConfig)

local StaffService = require(script.Parent.StaffService)
local Moderation = require(script.Parent.ModerationService)

local Service = {}

-- Diisi oleh CmdrServer (BindImpl) supaya aksi economy memakai logika perintah yang sama.
local Impl = nil

function Service.BindImpl(impl)
	Impl = impl
end

---------------------------------------------------------------- util
local function trim(value)
	return (string.gsub(value, "^%s*(.-)%s*$", "%1"))
end

local function text(value, maxLength)
	if type(value) ~= "string" then
		return ""
	end
	return string.sub(trim(value), 1, maxLength or 200)
end

local function number(value, minValue, maxValue)
	value = tonumber(value)
	if not value or value ~= value then
		return nil
	end
	return math.clamp(value, minValue, maxValue)
end

-- target boleh UserId (angka) atau nama / UserId dalam bentuk teks. Hasil: userId, nama.
local function resolveUser(target)
	local id = tonumber(target)
	if id and id > 0 and id % 1 == 0 then
		return id, StaffService.NameOf(id)
	end

	if type(target) == "string" then
		local name = trim(target)
		name = string.gsub(name, "^@", "")
		if name ~= "" then
			local online = Players:FindFirstChild(name)
			if online and online:IsA("Player") then
				return online.UserId, online.Name
			end
			local ok, userId = pcall(function()
				return Players:GetUserIdFromNameAsync(name)
			end)
			if ok and userId then
				return userId, name
			end
		end
	end

	return nil
end

-- Admin tidak boleh menindak staff yang setingkat atau lebih tinggi. Developer tidak bisa ditindak Developer lain.
local function canTarget(actor, actorRole, userId)
	if userId == actor.UserId then
		return true
	end
	local targetRole = StaffService.GetRoleOfUserId(userId)
	if not targetRole then
		return true
	end
	return StaffConfig.Roles[actorRole].Order < StaffConfig.Roles[targetRole].Order
end

local function onlineTarget(args, actor, role)
	local userId = resolveUser(args.Target)
	if not userId then
		return nil, "Player not found."
	end
	local player = Players:GetPlayerByUserId(userId)
	if not player then
		return nil, "That player is not in this server."
	end
	if not canTarget(actor, role, userId) then
		return nil, "You cannot act on a player with an equal or higher rank."
	end
	return player
end

local function economyTargets(args)
	if args.Target == "all" then
		return Players:GetPlayers()
	end
	local userId = resolveUser(args.Target)
	local player = userId and Players:GetPlayerByUserId(userId)
	if not player then
		return nil, "Pick a player that is in this server."
	end
	return { player }
end

---------------------------------------------------------------- aksi non-economy (Admin dan Developer)
local actions = {}

actions.announce = function(actor, role, args)
	local message = text(args.Text, StaffConfig.Announce.MaxLength)
	if message == "" then
		return false, "Write a message first."
	end
	local scope = args.Scope == "global" and "global" or "local"
	return Moderation.Announce(actor, message, scope)
end

actions.kick = function(actor, role, args)
	local target, err = onlineTarget(args, actor, role)
	if not target then
		return false, err
	end
	return Moderation.Kick(actor, target, text(args.Reason, 200))
end

actions.ban = function(actor, role, args)
	local userId, name = resolveUser(args.Target)
	if not userId then
		return false, "Player not found."
	end
	if userId == actor.UserId then
		return false, "You cannot ban yourself."
	end
	if not canTarget(actor, role, userId) then
		return false, "You cannot act on a player with an equal or higher rank."
	end
	local days = number(args.Days, 0, 3650) or 0
	return Moderation.Ban(actor, userId, name, text(args.Reason, 200), days)
end

actions.unban = function(actor, role, args)
	local userId, name = resolveUser(args.Target)
	if not userId then
		return false, "Player not found."
	end
	return Moderation.Unban(actor, userId, name)
end

local function targetAction(name, handler)
	actions[name] = function(actor, role, args)
		local target, err = onlineTarget(args, actor, role)
		if not target then
			return false, err
		end
		return handler(actor, target)
	end
end

targetAction("mute", Moderation.Mute)
targetAction("unmute", Moderation.Unmute)
targetAction("slap", Moderation.Slap)
targetAction("freeze", Moderation.Freeze)
targetAction("unfreeze", Moderation.Unfreeze)
targetAction("kill", Moderation.Kill)
targetAction("respawn", Moderation.Respawn)
targetAction("bring", Moderation.Bring)
targetAction("tpto", Moderation.TeleportTo)

actions.setstreamer = function(actor, role, args)
	local userId = resolveUser(args.Target)
	if not userId then
		return false, "Player not found."
	end
	return StaffService.SetStreamer(actor, userId, args.On == true)
end

actions.poll_start = function(actor, role, args)
	local options = {}
	if type(args.Options) == "table" then
		for _, option in ipairs(args.Options) do
			local value = text(option, 40)
			if value ~= "" then
				table.insert(options, value)
			end
			if #options >= StaffConfig.Poll.MaxOptions then
				break
			end
		end
	end

	local question = text(args.Question, StaffConfig.Poll.MaxTextLength)
	if question == "" or #options < 2 then
		return false, "A poll needs a question and at least 2 options."
	end

	local seconds = number(args.Seconds, StaffConfig.Poll.MinSeconds, StaffConfig.Poll.MaxSeconds) or 60
	return Moderation.StartPoll(actor, question, options, math.floor(seconds))
end

actions.poll_stop = function(actor)
	return Moderation.StopPoll(actor)
end

actions.stafflist = function()
	local lines = {}
	for index, entry in ipairs(StaffService.List()) do
		local label = StaffConfig.Roles[entry.Role].Label
		table.insert(lines, label .. " - " .. StaffService.NameOf(entry.UserId, index > 40) .. " (" .. entry.UserId .. ")")
	end
	if #lines == 0 then
		return true, "No staff yet."
	end
	return true, table.concat(lines, "\n")
end

---------------------------------------------------------------- aksi economy dan pengaturan penuh (Developer)
actions.setrole = function(actor, role, args)
	local userId = resolveUser(args.Target)
	if not userId then
		return false, "Player not found."
	end

	local roleName = nil
	if args.Role == "Admin" or args.Role == "ContentCreator" then
		roleName = args.Role
	elseif args.Role ~= "None" then
		return false, "Unknown role."
	end
	return StaffService.SetRole(actor, userId, roleName)
end

actions.give_money = function(actor, role, args)
	if not Impl then
		return false, "Economy actions are not ready yet."
	end
	local amount = number(args.Amount, 1, 1e15)
	if not amount then
		return false, "Enter an amount."
	end
	local targets, err = economyTargets(args)
	if not targets then
		return false, err
	end
	return true, Impl.give({ Executor = actor }, targets, "money", math.floor(amount))
end

actions.give_superthrows = function(actor, role, args)
	if not Impl then
		return false, "Economy actions are not ready yet."
	end
	local amount = number(args.Amount, 1, 1000)
	if not amount then
		return false, "Enter an amount."
	end
	local targets, err = economyTargets(args)
	if not targets then
		return false, err
	end
	return true, Impl.give({ Executor = actor }, targets, "superthrows", math.floor(amount))
end

local BOOST_KINDS = { luck = true, money = true, training = true }

actions.boost = function(actor, role, args)
	if not Impl then
		return false, "Economy actions are not ready yet."
	end
	if not BOOST_KINDS[args.Kind] then
		return false, "Pick a boost type."
	end
	local mult = number(args.Mult, 2, 1000)
	if not mult then
		return false, "Pick a multiplier."
	end
	local minutes = number(args.Minutes, 1, 600) or 15
	local scope = args.Scope == "global" and "global" or "local"
	return true, Impl.boost({ Executor = actor }, scope, args.Kind, math.floor(mult), math.floor(minutes * 60))
end

actions.cancelboost = function(actor, role, args)
	if not Impl then
		return false, "Economy actions are not ready yet."
	end
	if not BOOST_KINDS[args.Kind] and args.Kind ~= "all" then
		return false, "Pick a boost type."
	end
	local scope = args.Scope == "global" and "global" or "local"
	return true, Impl.cancelboost({ Executor = actor }, scope, args.Kind)
end

-- Event admin abuse manual: jam event dimulai dari sekarang (timeline 30 menit berjalan di server ini).
actions.abuse_start = function()
	workspace:SetAttribute("AdminAbuseSpeed", nil)
	workspace:SetAttribute("AdminAbuseTest", nil)
	workspace:SetAttribute("AdminAbuseStart", workspace:GetServerTimeNow())
	workspace:SetAttribute("AdminAbuseRun", (workspace:GetAttribute("AdminAbuseRun") or 0) + 1)
	return true, "Admin abuse event started on this server."
end

actions.abuse_stop = function()
	workspace:SetAttribute("AdminAbuseStart", nil)
	workspace:SetAttribute("AdminAbuseRun", (workspace:GetAttribute("AdminAbuseRun") or 0) + 1)
	return true, "Admin abuse event stopped on this server."
end

---------------------------------------------------------------- penerima
local lastCall = {}

local function handle(player, action, args)
	if type(action) ~= "string" then
		return false, "Bad request."
	end
	if type(args) ~= "table" then
		args = {}
	end

	local role = StaffService.GetRole(player)
	if not StaffConfig.CanDo(role, action) then
		return false, "You do not have permission for this action."
	end

	local handler = actions[action]
	if not handler then
		return false, "Unknown action."
	end

	local now = os.clock()
	if lastCall[player] and now - lastCall[player] < 0.25 then
		return false, "Slow down."
	end
	lastCall[player] = now

	local ok, success, message = pcall(handler, player, role, args)
	if not ok then
		warn("[StaffPanel] " .. action .. " failed: " .. tostring(success))
		return false, "Something went wrong."
	end

	return success == true, tostring(message or "")
end

function Service.Start()
	Moderation.Start()
	Remotes.Function("StaffPanel_Action").OnServerInvoke = handle
	Players.PlayerRemoving:Connect(function(player)
		lastCall[player] = nil
	end)
end

return Service
