-- StaffService (server): menyimpan role staff, menyinkronkannya antar server,
-- dan memasang nametag di atas kepala Developer / Admin / Content Creator.
-- Letak di Studio: ServerScriptService > Server > StaffService (ModuleScript)

local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local MessagingService = game:GetService("MessagingService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local StaffConfig = require(ReplicatedStorage.Config.StaffConfig)

local StaffService = {}

local ATTRIBUTE = StaffConfig.Attribute
local TAG_NAME = "StaffTag"
local ASSIGNABLE = { Admin = true, ContentCreator = true }

---------------------------------------------------------------- data
local storeName = StaffConfig.DataStoreName
if RunService:IsStudio() then
	storeName = storeName .. "_Studio" -- jangan mengotori data game asli saat mengetes
end

local store
pcall(function()
	store = DataStoreService:GetDataStore(storeName)
end)

-- Developer: tetap, dari config, maksimal MaxDevelopers orang.
local developerIds = {}
local developerSet = {}
for _, id in ipairs(StaffConfig.Developers) do
	if type(id) == "number" and id > 0 and not developerSet[id] then
		if #developerIds >= StaffConfig.MaxDevelopers then
			warn("[Staff] Developer melebihi batas " .. StaffConfig.MaxDevelopers .. ", UserId " .. id .. " diabaikan.")
		else
			developerSet[id] = true
			table.insert(developerIds, id)
		end
	end
end

-- Admin dan Content Creator: ["userId"] = "Admin" atau "ContentCreator".
local assigned = {}
local started = false

local function sanitize(raw)
	local clean = {}
	if type(raw) == "table" then
		for key, role in pairs(raw) do
			if ASSIGNABLE[role] and tonumber(key) then
				clean[tostring(key)] = role
			end
		end
	end
	return clean
end

local function loadAll()
	if not store then
		return false
	end

	local ok, result = pcall(function()
		return store:GetAsync(StaffConfig.DataStoreKey)
	end)
	if not ok then
		warn("[Staff] Gagal memuat daftar staff: " .. tostring(result))
		return false
	end

	assigned = sanitize(result)
	return true
end

-- Simpan satu perubahan. UpdateAsync membaca nilai terbaru dulu, jadi perubahan
-- dari server lain tidak tertimpa.
local function persist(key, roleName)
	if not store then
		return false, "DataStore not available"
	end

	local newValue
	local ok, err = pcall(function()
		newValue = store:UpdateAsync(StaffConfig.DataStoreKey, function(current)
			if type(current) ~= "table" then
				current = {}
			end
			current[key] = roleName -- nil = hapus
			return current
		end)
	end)
	if not ok then
		return false, tostring(err)
	end

	return true, newValue
end

---------------------------------------------------------------- role
function StaffService.GetRoleOfUserId(userId)
	if developerSet[userId] then
		return "Developer"
	end
	return assigned[tostring(userId)]
end

function StaffService.GetRole(player)
	if RunService:IsStudio() and StaffConfig.StudioEveryoneIsDeveloper then
		return "Developer"
	end
	return StaffService.GetRoleOfUserId(player.UserId)
end

local nameCache = {}

-- noLookup = true: jangan tanya Roblox untuk pemain offline (supaya daftar panjang tidak lambat).
function StaffService.NameOf(userId, noLookup)
	local online = Players:GetPlayerByUserId(userId)
	if online then
		return online.Name
	end
	if nameCache[userId] then
		return nameCache[userId]
	end
	if noLookup then
		return "?"
	end

	local ok, name = pcall(function()
		return Players:GetNameFromUserIdAsync(userId)
	end)
	if ok and name then
		nameCache[userId] = name
		return name
	end
	return "?"
end

-- Daftar semua staff, urut dari tingkat tertinggi.
function StaffService.List()
	local list = {}
	for _, id in ipairs(developerIds) do
		table.insert(list, { UserId = id, Role = "Developer" })
	end
	for key, role in pairs(assigned) do
		table.insert(list, { UserId = tonumber(key), Role = role })
	end

	table.sort(list, function(a, b)
		local orderA = StaffConfig.Roles[a.Role].Order
		local orderB = StaffConfig.Roles[b.Role].Order
		if orderA ~= orderB then
			return orderA < orderB
		end
		return a.UserId < b.UserId
	end)

	return list
end

local function applyToPlayer(player)
	local role = StaffService.GetRole(player)
	if player:GetAttribute(ATTRIBUTE) ~= role then
		player:SetAttribute(ATTRIBUTE, role)
	end
end

local function applyToAllPlayers()
	for _, player in ipairs(Players:GetPlayers()) do
		applyToPlayer(player)
	end
end

-- Menyimpan perubahan role, menerapkannya ke pemain, dan mengabari server lain.
local function commit(userId, roleName)
	local key = tostring(userId)
	local note = ""

	local ok, result = persist(key, roleName)
	if ok then
		if type(result) == "table" then
			assigned = sanitize(result)
		else
			assigned[key] = roleName
		end
	elseif RunService:IsStudio() then
		assigned[key] = roleName
		note = " (Studio: not saved)"
	else
		return false, "Could not save the change, try again. (" .. tostring(result) .. ")"
	end

	local target = Players:GetPlayerByUserId(userId)
	if target then
		applyToPlayer(target)
	end

	-- kabari server lain
	task.spawn(function()
		pcall(function()
			MessagingService:PublishAsync(StaffConfig.MessagingTopic, {
				JobId = game.JobId,
				UserId = userId,
				Role = roleName,
			})
		end)
	end)

	local name = StaffService.NameOf(userId)
	if roleName then
		return true, name .. " is now " .. StaffConfig.Roles[roleName].Label .. "." .. note
	end
	return true, name .. " is no longer staff." .. note
end

local function validUserId(userId)
	return type(userId) == "number" and userId > 0 and userId % 1 == 0
end

-- Mengubah role seseorang. actor = pemain yang menjalankan perintah (harus Developer).
-- roleName: "Admin", "ContentCreator", atau nil untuk menghapus role.
-- Hasil: ok (boolean), pesan (string).
function StaffService.SetRole(actor, userId, roleName)
	if not actor or StaffService.GetRole(actor) ~= "Developer" then
		return false, "Only Developers can change staff roles."
	end
	if not validUserId(userId) then
		return false, "Invalid UserId."
	end
	if developerSet[userId] then
		return false, "Developers are set in StaffConfig and cannot be changed here."
	end
	if roleName ~= nil and not ASSIGNABLE[roleName] then
		return false, "Unknown role."
	end

	return commit(userId, roleName)
end

-- Menjadikan pemain Content Creator (streamer) atau mencabutnya. Boleh dilakukan Admin dan Developer.
-- Admin dan Developer tidak bisa diubah lewat sini.
function StaffService.SetStreamer(actor, userId, on)
	local actorRole = actor and StaffService.GetRole(actor)
	if not StaffConfig.CanDo(actorRole, "setstreamer") then
		return false, "You do not have permission for this action."
	end
	if not validUserId(userId) then
		return false, "Invalid UserId."
	end

	local current = StaffService.GetRoleOfUserId(userId)
	if current == "Developer" or current == "Admin" then
		return false, "That player is already " .. StaffConfig.Roles[current].Label .. "."
	end

	if on then
		if current == "ContentCreator" then
			return false, "That player is already a Content Creator."
		end
		return commit(userId, "ContentCreator")
	end

	if current ~= "ContentCreator" then
		return false, "That player is not a Content Creator."
	end
	return commit(userId, nil)
end

---------------------------------------------------------------- nametag
local function buildTag(head, def)
	local nametag = StaffConfig.Nametag
	local width = math.max(70, #def.Label * 10 + 24)

	local gui = Instance.new("BillboardGui")
	gui.Name = TAG_NAME
	gui.Adornee = head
	gui.Size = UDim2.fromOffset(width, 26)
	gui.StudsOffset = nametag.StudsOffset
	gui.MaxDistance = nametag.MaxDistance
	gui.AlwaysOnTop = false
	gui.LightInfluence = 0

	local pill = Instance.new("Frame")
	pill.Name = "Pill"
	pill.Size = UDim2.fromScale(1, 1)
	pill.BackgroundColor3 = Color3.fromRGB(15, 15, 20)
	pill.BackgroundTransparency = 0.25
	pill.BorderSizePixel = 0
	pill.Parent = gui

	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 8)
	corner.Parent = pill

	local stroke = Instance.new("UIStroke")
	stroke.Color = def.Color
	stroke.Thickness = 1.5
	stroke.Parent = pill

	local label = Instance.new("TextLabel")
	label.Name = "Role"
	label.BackgroundTransparency = 1
	label.Size = UDim2.fromScale(1, 1)
	label.Font = Enum.Font.GothamBold
	label.Text = def.Label
	label.TextColor3 = def.Color
	label.TextSize = nametag.TextSize
	label.Parent = pill

	-- Sembunyikan tag kalau kepala dibuat transparan (karakter disembunyikan saat training).
	local function sync()
		gui.Enabled = head.Transparency < 1
	end
	head:GetPropertyChangedSignal("Transparency"):Connect(sync)
	sync()

	return gui
end

local function refreshTag(player)
	local character = player.Character
	if not character then
		return
	end

	local head = character:FindFirstChild("Head") or character:WaitForChild("Head", 10)
	if not head or not head:IsA("BasePart") then
		return
	end

	-- Tidak ada yield di bawah ini: tag lama dihapus dan yang baru dipasang dalam satu langkah.
	local old = head:FindFirstChild(TAG_NAME)
	if old then
		old:Destroy()
	end

	local role = player:GetAttribute(ATTRIBUTE)
	local def = role and StaffConfig.Roles[role]
	if not def then
		return
	end

	buildTag(head, def).Parent = head
end

local function trackPlayer(player)
	applyToPlayer(player)

	player:GetAttributeChangedSignal(ATTRIBUTE):Connect(function()
		task.spawn(refreshTag, player)
	end)
	player.CharacterAdded:Connect(function()
		task.spawn(refreshTag, player)
	end)

	if player.Character then
		task.spawn(refreshTag, player)
	end
end

---------------------------------------------------------------- start
function StaffService.Start()
	if started then
		return
	end
	started = true

	Players.PlayerAdded:Connect(trackPlayer)
	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(trackPlayer, player)
	end

	-- terima perubahan role dari server lain
	task.spawn(function()
		pcall(function()
			MessagingService:SubscribeAsync(StaffConfig.MessagingTopic, function(message)
				local data = message.Data
				if type(data) ~= "table" or data.JobId == game.JobId then
					return
				end

				local userId = tonumber(data.UserId)
				if not userId then
					return
				end

				local role = data.Role
				if not ASSIGNABLE[role] then
					role = nil
				end
				assigned[tostring(userId)] = role

				local target = Players:GetPlayerByUserId(userId)
				if target then
					applyToPlayer(target)
				end
			end)
		end)
	end)

	-- muat daftar Admin / Content Creator dari DataStore (coba lagi kalau gagal)
	task.spawn(function()
		for _ = 1, 6 do
			if loadAll() or not store then
				break
			end
			task.wait(10)
		end
		applyToAllPlayers()
	end)
end

return StaffService
