
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PlayerTroves = require(script.Parent.Controllers.PlayerTroves)
local Promise = require(ReplicatedStorage.Packages.Promise)
require(ReplicatedStorage.Packages.Trove)

local function traceback(p)
	return debug.traceback(tostring(p), 2)
end

local Controllers = script.Parent:WaitForChild("Controllers")

local v = {
	"DataController",
	"UIScaler",
	"InputActions",
	"GamepadFocus",
	"Sounds",
	"MusicController",
	"RobuxPrices",
	"ScreenFX",
	"CameraRig",
	"FogController",
	"UIKit",
	"UIBackdrop",
	"HUDController",
	"PowerSlider",
	"PokemonController",
	"AnimalVisuals",
	"TrainingVisuals",
	"TrainingController",
	"ShopController",
	"PlotController",
	"PlotTags",
	"IndexController",
	"AnimalsPanel",
	"SellShop",
	"ProtectedSell",
	"Inventory",
	"ExclusiveShopController",
	"ShopFX",
	"GiftController",
	"EggController",
	"Tutorial",
	"UpgradePopups",
	"ReleaseController",
	"ReleaseShow",
	"AdminAbuseController",
	"EventFollow",
	"UIFocus",
	"OfflineEarnings",
	"SuperThrow",
	"ThrowController",
	"PackOffers",
	"DevPanel",
	"NewAnimalView",
	"NewAnimalsTelemetry",
	"AFKRejoin",
	"Announcements",
	"StaffPanel",
	"StaffPoll",
	"GameSettings",
	"RingRushEventController"
}

local v2 = {}

for _, childName in v do
	local child = Controllers:FindFirstChild(childName)

	if child then
		local success, result = xpcall(require, traceback, child)

		if success then
			v2[childName] = result
		else
			warn(`[ClientMain] Failed to require {childName}: {result}`)
		end
	else
		warn(`[ClientMain] Missing controller: {childName}`)
	end
end

local sounds = v2.Sounds

if type(sounds) == "table" and sounds.Preload then
	local success, result = xpcall(sounds.Preload, traceback)

	if not success then
		warn(`[ClientMain] Sounds.Preload failed: {result}`)
	end
end

for _, v3 in v do
	local v4 = v2[v3]

	if not (type(v4) == "table" and v4.Init) then
		continue
	end

	local success, result = xpcall(v4.Init, traceback)

	if not success then
		warn(`[ClientMain] {v3}.Init failed: {result}`)
	end
end

print("[ClientMain] Client started")

local function getLoadOrder(moduleScript) -- 1 equivalent call inferred from this helper
	local loadOrder = moduleScript:GetAttribute("LoadOrder")

	if loadOrder == nil then
		return 0
	end

	if type(loadOrder) == "number" then
		return loadOrder
	end

	warn(`[ClientMain] {moduleScript:GetFullName()} has a LoadOrder that is not a number`)
	return 0
end

local function getLifecycleScripts()
	local moduleScripts = {}
	local v3 = {}

	for _, moduleScript in script:GetChildren() do
		if not moduleScript:IsA("ModuleScript") then
			continue
		end

		table.insert(moduleScripts, moduleScript)
		v3[moduleScript] = getLoadOrder(moduleScript) -- inferred equivalent call
	end

	table.sort(moduleScripts, function(a, b): boolean
		if v3[a] == v3[b] then
			return a.Name < b.Name
		end

		return v3[a] < v3[b]
	end)

	return moduleScripts
end

local function runWatched(fullName: string, callback, ...)
	local v3 = Promise.delay(30):andThen(function()
		warn(`{fullName} TIMED OUT`)
	end)
	local success, result = xpcall(callback, traceback, ...)
	v3:cancel()
	return success, result
end

local function runHook(p: string, p2: string, callback, ...)
	local success, result = xpcall(callback, traceback, ...)

	if not success then
		warn(`[ClientMain] {p}.{p2} failed: {result}`)
	end
end

local function spawnHook(fullName: string, p: string, callback, ...)
	task.spawn(runHook, fullName, p, callback, ...)
end

local function getHook(p, p2: string)
	local export = p.Exports[p2]

	if export == nil or type(export) == "function" then
		return export
	end

	warn(`[ClientMain] {p.FullName}.{p2} is not a function`)
	return nil
end

local function requireLifecycleModules(dataController)
	local result = {}

	for _, v3 in getLifecycleScripts() do
		local fullName = v3:GetFullName()
		local v4, exports = runWatched(fullName, require, v3)

		if v4 then
			if type(exports) == "table" then
				if dataController and not table.isfrozen(exports) then
					exports.DataController = dataController
				end

				table.insert(result, { FullName = fullName, Exports = exports })
			else
				warn(`[ClientMain] {fullName} must return a table`)
			end
		else
			warn(`[ClientMain] Failed to require {fullName}: {exports}`)
		end
	end

	return result
end

local function initLifecycleModules(items)
	local result = {}

	for _, item in items do
		local init = item.Exports.init

		if init ~= nil and type(init) ~= "function" then
			warn(`[ClientMain] {item.FullName}.init is not a function`)
			init = nil
		end

		if init then
			local v3, v4 = runWatched(item.FullName, init)

			if not v3 then
				warn(`[ClientMain] {item.FullName}.init failed, its hooks stay off: {v4}`)
				continue
			end
		end

		local v3 = {
			FullName = item.FullName,
			OnProfileAdded = 0,
			OnCharacterAdded = 0,
			OnDied = 0
		}
		local onProfileAdded = item.Exports.onProfileAdded

		if onProfileAdded ~= nil and type(onProfileAdded) ~= "function" then
			warn(`[ClientMain] {item.FullName}.onProfileAdded is not a function`)
			onProfileAdded = nil
		end

		v3.OnProfileAdded = onProfileAdded
		local onCharacterAdded = item.Exports.onCharacterAdded

		if onCharacterAdded ~= nil and type(onCharacterAdded) ~= "function" then
			warn(`[ClientMain] {item.FullName}.onCharacterAdded is not a function`)
			onCharacterAdded = nil
		end

		v3.OnCharacterAdded = onCharacterAdded
		local onDied = item.Exports.onDied

		if onDied ~= nil and type(onDied) ~= "function" then
			warn(`[ClientMain] {item.FullName}.onDied is not a function`)
			onDied = nil
		end

		v3.OnDied = onDied
		table.insert(result, v3)
	end

	return result
end

local function watchProfile(items, dataController)
	if not (dataController and dataController.ProfileReady and dataController.GetData) then
		warn("[ClientMain] DataController has no ProfileReady / GetData: onProfileAdded hooks will not run")

		return
	end

	local flag = false
	local function deliver(p)
		if flag then
			return
		end

		flag = true

		for _, item in items do
			if item.OnProfileAdded then
				spawnHook(item.FullName, "onProfileAdded", item.OnProfileAdded, p)
			end
		end
	end

	local profileReadyConnection = nil
	profileReadyConnection = dataController.ProfileReady:Connect(function(p)
		profileReadyConnection:Disconnect()
		deliver(p)
	end)
	local data = dataController:IsReady() and dataController:GetData()

	if data then
		profileReadyConnection:Disconnect()
		deliver(data)
	end
end

local function watchCharacter(items)
	local localPlayer = Players.LocalPlayer

	local set = {}
	setmetatable(set, { __mode = "k" })

	local function startCharacter(p, humanoid, characterTrove)
		characterTrove:Add(humanoid.Died:Once(function()
			for _, item in items do
				if item.OnDied then
					spawnHook(item.FullName, "onDied", item.OnDied)
				end
			end
		end))

		for _, item in items do
			if item.OnCharacterAdded then
				spawnHook(item.FullName, "onCharacterAdded", item.OnCharacterAdded, p, humanoid, characterTrove)
			end
		end
	end

	local function onCharacterAdded(instance)
		if set[instance] then
			return
		end

		local characterTrove = PlayerTroves.GetCharacterTrove()

		if not characterTrove or localPlayer.Character ~= instance then
			return
		end

		set[instance] = true
		task.spawn(function()
			local humanoid = instance:WaitForChild("Humanoid", 30)

			if localPlayer.Character ~= instance or not instance.Parent then
				return
			end

			if humanoid and humanoid:IsA("Humanoid") then
				startCharacter(instance, humanoid, characterTrove)
			else
				warn(`[ClientMain] {instance:GetFullName()} has no Humanoid after {30} s`)
			end
		end)
	end

	localPlayer.CharacterAdded:Connect(onCharacterAdded)

	if localPlayer.Character then
		local character = localPlayer.Character

		if set[character] then
			return
		end

		local characterTrove = PlayerTroves.GetCharacterTrove()

		if characterTrove then
			if localPlayer.Character ~= character then
				return
			end

			set[character] = true
			task.spawn(function()
				local humanoid = character:WaitForChild("Humanoid", 30)

				if localPlayer.Character ~= character or not character.Parent then
					return
				end

				if humanoid and humanoid:IsA("Humanoid") then
					startCharacter(character, humanoid, characterTrove)
				else
					warn(`[ClientMain] {character:GetFullName()} has no Humanoid after {30} s`)
				end
			end)
		end
	end
end

local function startLifecycleModules()
	local dataController = v2.DataController
	local v3 = initLifecycleModules(requireLifecycleModules(dataController))
	local v4 = false
	local flag = false

	for _, v5 in v3 do
		v4 = v5.OnProfileAdded and true or v4

		if v5.OnCharacterAdded or v5.OnDied then
			flag = true
		end
	end

	if v4 then
		watchProfile(v3, dataController)
	end

	if flag then
		watchCharacter(v3)
	end
end

startLifecycleModules()