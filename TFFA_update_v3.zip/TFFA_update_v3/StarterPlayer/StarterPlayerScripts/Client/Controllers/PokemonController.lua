-- PokemonController (client): memakai model Pokémon yang dimuat server (ReplicatedStorage.PokemonAnimals)
-- menggantikan model hewan lewat AnimalTemplates.SetOverride. Kalau modelnya tidak ada, model asli dipakai.
-- Letak di Studio: StarterPlayerScripts > Client > Controllers > PokemonController (ModuleScript)

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PokemonConfig = require(ReplicatedStorage.Config.PokemonConfig)
local AnimalTemplates = require(ReplicatedStorage.Shared.AnimalTemplates)

local PokemonController = {}

if PokemonConfig.Enabled then
	-- di dalam task.spawn supaya controller lain tidak ikut menunggu
	task.spawn(function()
		local folder = ReplicatedStorage:WaitForChild(PokemonConfig.FolderName, 60)
		if not folder then
			warn("[Pokemon] Folder " .. PokemonConfig.FolderName .. " tidak ditemukan, memakai model hewan asli.")
			return
		end

		local function install()
			AnimalTemplates.SetOverride(function(name)
				return folder:FindFirstChild(name)
			end)
		end
		install()

		-- model datang bertahap dari server: muat ulang tampilan sesekali, bukan tiap model
		local pending = false
		local function refresh()
			if pending then
				return
			end
			pending = true
			task.delay(1.5, function()
				pending = false
				install()
			end)
		end

		folder.ChildAdded:Connect(refresh)
		folder:GetAttributeChangedSignal("Ready"):Connect(refresh)
	end)
end

return PokemonController
