-- StaffPanel (client): panel STAFF untuk Developer dan Admin.
--   Developer: semua tab (Players, Announce, Poll, Boosts, Event, Staff)
--   Admin    : hanya tab non-economy (Players, Announce, Poll)
-- Dibuka dengan tombol STAFF atau tombol F3 (diatur di StaffConfig.Panel).
-- Semua aksi dikirim ke server dan dicek ulang di sana (StaffPanelService).
-- Letak di Studio: StarterPlayerScripts > Client > Controllers > StaffPanel (ModuleScript)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local StaffConfig = require(ReplicatedStorage.Config.StaffConfig)
local AdminsConfig = require(ReplicatedStorage.Config.AdminsConfig)

local player = Players.LocalPlayer
local invoke = Remotes.Function("StaffPanel_Action")

local StaffPanel = {}

local COLORS = {
	bg = Color3.fromRGB(24, 26, 34),
	panel = Color3.fromRGB(40, 44, 58),
	field = Color3.fromRGB(18, 20, 27),
	text = Color3.fromRGB(235, 238, 245),
	muted = Color3.fromRGB(150, 156, 172),
	accent = Color3.fromRGB(70, 130, 240),
	good = Color3.fromRGB(50, 160, 100),
	bad = Color3.fromRGB(210, 70, 80),
	warn = Color3.fromRGB(215, 145, 40),
}

local LEFT = Enum.TextXAlignment.Left

---------------------------------------------------------------- helper UI
local function new(className, props, parent)
	local instance = Instance.new(className)
	for key, value in pairs(props) do
		instance[key] = value
	end
	if parent then
		instance.Parent = parent
	end
	return instance
end

local function trim(value)
	return (string.gsub(value, "^%s*(.-)%s*$", "%1"))
end

local function corner(parent, radius)
	return new("UICorner", { CornerRadius = UDim.new(0, radius or 8) }, parent)
end

local function makeButton(parent, label, color, callback, size)
	local button = new("TextButton", {
		Text = label,
		Font = Enum.Font.GothamBold,
		TextSize = 14,
		TextColor3 = COLORS.text,
		BackgroundColor3 = color or COLORS.accent,
		BorderSizePixel = 0,
		AutoButtonColor = true,
		Size = size or UDim2.fromOffset(110, 34),
	}, parent)
	corner(button)
	button.Activated:Connect(callback)
	return button
end

local function makeBox(parent, placeholder, multiline, height)
	local box = new("TextBox", {
		Text = "",
		PlaceholderText = placeholder,
		PlaceholderColor3 = COLORS.muted,
		TextColor3 = COLORS.text,
		Font = Enum.Font.Gotham,
		TextSize = 14,
		TextXAlignment = LEFT,
		TextYAlignment = multiline and Enum.TextYAlignment.Top or Enum.TextYAlignment.Center,
		TextWrapped = multiline == true,
		MultiLine = multiline == true,
		ClearTextOnFocus = false,
		BackgroundColor3 = COLORS.field,
		BorderSizePixel = 0,
		Size = UDim2.new(1, 0, 0, height or 34),
	}, parent)
	corner(box)
	new("UIPadding", {
		PaddingLeft = UDim.new(0, 10),
		PaddingRight = UDim.new(0, 10),
		PaddingTop = UDim.new(0, multiline and 8 or 0),
	}, box)
	return box
end

local function makeLabel(parent, text, color, size)
	return new("TextLabel", {
		BackgroundTransparency = 1,
		Text = text,
		Font = Enum.Font.GothamMedium,
		TextSize = size or 13,
		TextColor3 = color or COLORS.muted,
		TextXAlignment = LEFT,
		TextWrapped = true,
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
	}, parent)
end

local function makeSection(parent, text)
	return makeLabel(parent, string.upper(text), COLORS.text, 12)
end

local function makeRow(parent)
	local row = new("Frame", { BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 36) }, parent)
	new("UIListLayout", {
		FillDirection = Enum.FillDirection.Horizontal,
		Padding = UDim.new(0, 6),
		SortOrder = Enum.SortOrder.LayoutOrder,
	}, row)
	return row
end

-- Deretan tombol pilihan (satu terpilih). Hasil: fungsi untuk membaca nilai terpilih.
local function makeChoice(parent, labels, values, defaultIndex, onChange)
	local row = makeRow(parent)
	local buttons = {}
	local current = defaultIndex

	local function paint()
		for index, button in ipairs(buttons) do
			button.BackgroundColor3 = index == current and COLORS.accent or COLORS.panel
		end
	end

	for index, label in ipairs(labels) do
		local button = makeButton(row, label, COLORS.panel, function()
			current = index
			paint()
			if onChange then
				onChange(values[index])
			end
		end, UDim2.new(0, 0, 1, 0))
		button.AutomaticSize = Enum.AutomaticSize.X
		new("UIPadding", { PaddingLeft = UDim.new(0, 12), PaddingRight = UDim.new(0, 12) }, button)
		button.LayoutOrder = index
		buttons[index] = button
	end

	paint()
	return function()
		return values[current]
	end
end

local function makePage(parent)
	local page = new("ScrollingFrame", {
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Size = UDim2.fromScale(1, 1),
		CanvasSize = UDim2.new(),
		AutomaticCanvasSize = Enum.AutomaticSize.Y,
		ScrollBarThickness = 4,
		Visible = false,
	}, parent)
	new("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }, page)
	new("UIPadding", {
		PaddingLeft = UDim.new(0, 2),
		PaddingRight = UDim.new(0, 8),
		PaddingTop = UDim.new(0, 4),
		PaddingBottom = UDim.new(0, 10),
	}, page)
	return page
end

---------------------------------------------------------------- state
local gui = nil
local window = nil
local statusLabel = nil
local builtRole = nil
local connections = {}
local selected = nil -- { UserId = ..., Name = ... }
local selectionLabels = {}
local statusToken = 0
local busy = false

local function say(message, isError)
	if not statusLabel then
		return
	end
	statusToken = statusToken + 1
	local token = statusToken
	statusLabel.Text = message
	statusLabel.TextColor3 = isError and COLORS.bad or COLORS.good
	task.delay(10, function()
		if statusLabel and statusToken == token then
			statusLabel.Text = ""
		end
	end)
end

local function selectionText()
	if selected then
		return "Selected player: " .. selected.Name
	end
	return "No player selected (pick one in the Players tab)"
end

local function setSelected(userId, name)
	selected = { UserId = userId, Name = name }
	for _, label in ipairs(selectionLabels) do
		if label.Parent then
			label.Text = selectionText()
		end
	end
end

local function act(action, args)
	if busy then
		return
	end
	busy = true
	say("Working...", false)

	local ok, success, message = pcall(function()
		return invoke:InvokeServer(action, args)
	end)
	busy = false

	if not ok then
		say("The request failed, try again.", true)
		return
	end
	if message == nil or message == "" then
		message = success and "Done." or "Failed."
	end
	say(message, not success)
end

local function destroy()
	for _, connection in ipairs(connections) do
		connection:Disconnect()
	end
	connections = {}
	selectionLabels = {}
	if gui then
		gui:Destroy()
	end
	gui, window, statusLabel, builtRole = nil, nil, nil, nil
end

---------------------------------------------------------------- tab: Players
local builders = {}

builders.players = function(page)
	local selectionLabel = makeLabel(page, selectionText(), COLORS.text, 13)
	table.insert(selectionLabels, selectionLabel)

	local list = new("ScrollingFrame", {
		BackgroundColor3 = COLORS.field,
		BorderSizePixel = 0,
		Size = UDim2.new(1, 0, 0, 130),
		CanvasSize = UDim2.new(),
		AutomaticCanvasSize = Enum.AutomaticSize.Y,
		ScrollBarThickness = 4,
	}, page)
	corner(list)
	new("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.Name }, list)
	new("UIPadding", {
		PaddingLeft = UDim.new(0, 6),
		PaddingRight = UDim.new(0, 6),
		PaddingTop = UDim.new(0, 6),
		PaddingBottom = UDim.new(0, 6),
	}, list)

	local function refreshList()
		for _, child in ipairs(list:GetChildren()) do
			if child:IsA("TextButton") then
				child:Destroy()
			end
		end
		for _, other in ipairs(Players:GetPlayers()) do
			local row = makeButton(list, other.DisplayName .. "  (@" .. other.Name .. ")", COLORS.panel, function()
				setSelected(other.UserId, other.Name)
			end, UDim2.new(1, 0, 0, 30))
			row.Name = string.lower(other.Name)
			row.TextXAlignment = LEFT
			new("UIPadding", { PaddingLeft = UDim.new(0, 10) }, row)
		end
	end
	refreshList()
	table.insert(connections, Players.PlayerAdded:Connect(refreshList))
	table.insert(connections, Players.PlayerRemoving:Connect(function()
		task.delay(0.2, refreshList)
	end))

	local typedBox = makeBox(page, "Or type a name / UserId (for offline ban or unban)")
	local reasonBox = makeBox(page, "Reason (optional)")
	local daysBox = makeBox(page, "Ban days (empty = permanent)")

	local function target()
		local typed = trim(typedBox.Text)
		if typed ~= "" then
			return typed
		end
		return selected and selected.UserId or nil
	end

	local grid = new("Frame", {
		BackgroundTransparency = 1,
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
	}, page)
	new("UIGridLayout", {
		CellSize = UDim2.new(0.333, -6, 0, 36),
		CellPadding = UDim2.fromOffset(6, 6),
		SortOrder = Enum.SortOrder.LayoutOrder,
	}, grid)

	local buttons = {
		{ "Kick", "kick", COLORS.warn },
		{ "Ban", "ban", COLORS.bad },
		{ "Unban", "unban", COLORS.good },
		{ "Mute", "mute", COLORS.warn },
		{ "Unmute", "unmute", COLORS.good },
		{ "Slap", "slap", COLORS.warn },
		{ "Freeze", "freeze", COLORS.accent },
		{ "Unfreeze", "unfreeze", COLORS.good },
		{ "Kill", "kill", COLORS.bad },
		{ "Respawn", "respawn", COLORS.accent },
		{ "Bring", "bring", COLORS.accent },
		{ "Go to", "tpto", COLORS.accent },
		{ "Streamer ON", "setstreamer", COLORS.good, true },
		{ "Streamer OFF", "setstreamer", COLORS.warn, false },
	}
	for index, entry in ipairs(buttons) do
		local button = makeButton(grid, entry[1], entry[3], function()
			local who = target()
			if not who then
				say("Select a player first.", true)
				return
			end
			act(entry[2], {
				Target = who,
				Reason = reasonBox.Text,
				Days = tonumber(daysBox.Text),
				On = entry[4],
			})
		end, UDim2.new())
		button.LayoutOrder = index
	end
end

---------------------------------------------------------------- tab: Announce
builders.announce = function(page)
	makeSection(page, "Announcement")
	local box = makeBox(page, "Message for all players", true, 90)
	local scope = "local"
	makeChoice(page, { "This server", "All servers" }, { "local", "global" }, 1, function(value)
		scope = value
	end)
	makeButton(page, "Send announcement", COLORS.accent, function()
		act("announce", { Text = box.Text, Scope = scope })
		box.Text = ""
	end, UDim2.fromOffset(180, 36))
end

---------------------------------------------------------------- tab: Poll
builders.poll = function(page)
	makeSection(page, "New poll (this server)")
	local question = makeBox(page, "Question")
	local optionBoxes = {}
	for index = 1, StaffConfig.Poll.MaxOptions do
		optionBoxes[index] = makeBox(page, "Option " .. index .. (index <= 2 and "" or " (optional)"))
	end
	local seconds = makeBox(page, "Seconds (default 60)")

	local row = makeRow(page)
	makeButton(row, "Start poll", COLORS.good, function()
		local options = {}
		for _, box in ipairs(optionBoxes) do
			table.insert(options, box.Text)
		end
		act("poll_start", {
			Question = question.Text,
			Options = options,
			Seconds = tonumber(seconds.Text),
		})
	end, UDim2.fromOffset(120, 36))
	makeButton(row, "Stop poll", COLORS.bad, function()
		act("poll_stop", {})
	end, UDim2.fromOffset(120, 36))
end

---------------------------------------------------------------- tab: Boosts (Developer)
builders.boosts = function(page)
	makeSection(page, "Boost type")
	local getKind = makeChoice(page, { "Luck", "Money", "Training" }, { "luck", "money", "training" }, 1)

	makeSection(page, "Multiplier")
	local getMult = makeChoice(page, { "x2", "x4", "x8", "x16", "x32" }, { 2, 4, 8, 16, 32 }, 1)

	makeSection(page, "Duration and scope")
	local minutes = makeBox(page, "Minutes (default 15)")
	local getScope = makeChoice(page, { "This server", "All servers" }, { "local", "global" }, 1)

	makeButton(page, "Apply boost", COLORS.good, function()
		act("boost", {
			Kind = getKind(),
			Mult = getMult(),
			Minutes = tonumber(minutes.Text),
			Scope = getScope(),
		})
	end, UDim2.fromOffset(180, 36))

	local row = makeRow(page)
	makeButton(row, "Cancel this type", COLORS.warn, function()
		act("cancelboost", { Kind = getKind(), Scope = getScope() })
	end, UDim2.fromOffset(140, 36))
	makeButton(row, "Cancel all", COLORS.bad, function()
		act("cancelboost", { Kind = "all", Scope = getScope() })
	end, UDim2.fromOffset(110, 36))

	makeLabel(page, "Boosts stack with each other and with the admin abuse event. The server caps the final multiplier.")
end

---------------------------------------------------------------- tab: Event (Developer)
builders.event = function(page)
	makeSection(page, "Admin abuse event (this server)")
	local row = makeRow(page)
	makeButton(row, "Start event", COLORS.good, function()
		act("abuse_start", {})
	end, UDim2.fromOffset(120, 36))
	makeButton(row, "Stop event", COLORS.bad, function()
		act("abuse_stop", {})
	end, UDim2.fromOffset(120, 36))
	makeLabel(page, "Starts the 30-minute timeline now: host messages, Luck up to x32, Money up to x16, Training up to x8, free lucky throws and the map vote.")

	local selectionLabel = makeLabel(page, selectionText(), COLORS.text, 13)
	table.insert(selectionLabels, selectionLabel)

	makeSection(page, "Lucky throws")
	local luckyBox = makeBox(page, "Amount (default 1)")
	local luckyRow = makeRow(page)
	makeButton(luckyRow, "Give everyone", COLORS.good, function()
		act("give_superthrows", { Target = "all", Amount = tonumber(luckyBox.Text) or 1 })
	end, UDim2.fromOffset(130, 36))
	makeButton(luckyRow, "Give selected", COLORS.accent, function()
		if not selected then
			say("Select a player in the Players tab first.", true)
			return
		end
		act("give_superthrows", { Target = selected.UserId, Amount = tonumber(luckyBox.Text) or 1 })
	end, UDim2.fromOffset(130, 36))

	makeSection(page, "Money")
	local moneyBox = makeBox(page, "Amount")
	makeButton(page, "Give money to selected", COLORS.accent, function()
		if not selected then
			say("Select a player in the Players tab first.", true)
			return
		end
		act("give_money", { Target = selected.UserId, Amount = tonumber(moneyBox.Text) })
	end, UDim2.fromOffset(200, 36))
end

---------------------------------------------------------------- tab: Staff (Developer)
builders.staff = function(page)
	makeSection(page, "Staff roles")
	local selectionLabel = makeLabel(page, selectionText(), COLORS.text, 13)
	table.insert(selectionLabels, selectionLabel)
	local typedBox = makeBox(page, "Or type a name / UserId")

	local function target()
		local typed = trim(typedBox.Text)
		if typed ~= "" then
			return typed
		end
		return selected and selected.UserId or nil
	end

	local function setRole(roleName)
		local who = target()
		if not who then
			say("Select a player first.", true)
			return
		end
		act("setrole", { Target = who, Role = roleName })
	end

	local row = makeRow(page)
	makeButton(row, "Admin", COLORS.accent, function()
		setRole("Admin")
	end, UDim2.fromOffset(90, 36))
	makeButton(row, "Creator", COLORS.good, function()
		setRole("ContentCreator")
	end, UDim2.fromOffset(90, 36))
	makeButton(row, "Remove", COLORS.bad, function()
		setRole("None")
	end, UDim2.fromOffset(90, 36))

	makeSection(page, "Current staff")
	local listLabel = makeLabel(page, "Press the button to load the list.", COLORS.text, 13)
	makeButton(page, "Refresh staff list", COLORS.panel, function()
		local ok, success, message = pcall(function()
			return invoke:InvokeServer("stafflist", {})
		end)
		if ok and success then
			listLabel.Text = message
		else
			say("Could not load the staff list.", true)
		end
	end, UDim2.fromOffset(180, 36))
end

---------------------------------------------------------------- bangun panel
local function build(role)
	destroy()
	builtRole = role
	local roleDef = StaffConfig.Roles[role]

	gui = new("ScreenGui", {
		Name = "StaffPanelGui",
		ResetOnSpawn = false,
		DisplayOrder = 60,
		ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	}, player:WaitForChild("PlayerGui"))

	local openButton = new("TextButton", {
		Name = "Open",
		Text = StaffConfig.Panel.ButtonText,
		Font = Enum.Font.GothamBold,
		TextSize = 14,
		TextColor3 = roleDef.Color,
		BackgroundColor3 = COLORS.bg,
		BackgroundTransparency = 0.1,
		BorderSizePixel = 0,
		Position = StaffConfig.Panel.ButtonPosition,
		Size = UDim2.fromOffset(64, 34),
	}, gui)
	corner(openButton)
	new("UIStroke", { Color = roleDef.Color, Thickness = 1.5 }, openButton)

	window = new("Frame", {
		Name = "Window",
		Visible = false,
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.5),
		Size = UDim2.fromScale(0.94, 0.86),
		BackgroundColor3 = COLORS.bg,
		BorderSizePixel = 0,
	}, gui)
	corner(window, 12)
	new("UISizeConstraint", { MaxSize = Vector2.new(560, 470) }, window)
	new("UIStroke", { Color = roleDef.Color, Thickness = 1.5 }, window)

	-- header
	local title = makeLabel(window, "STAFF PANEL  -  " .. roleDef.Label, roleDef.Color, 15)
	title.Font = Enum.Font.GothamBold
	title.Position = UDim2.fromOffset(14, 10)
	title.Size = UDim2.new(1, -70, 0, 24)
	title.AutomaticSize = Enum.AutomaticSize.None

	local closeButton = makeButton(window, "X", COLORS.bad, function()
		window.Visible = false
	end, UDim2.fromOffset(34, 28))
	closeButton.Position = UDim2.new(1, -44, 0, 8)

	-- tab bar
	local tabBar = new("ScrollingFrame", {
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Position = UDim2.fromOffset(10, 44),
		Size = UDim2.new(1, -20, 0, 38),
		CanvasSize = UDim2.new(),
		AutomaticCanvasSize = Enum.AutomaticSize.X,
		ScrollBarThickness = 0,
		ScrollingDirection = Enum.ScrollingDirection.X,
	}, window)
	new("UIListLayout", {
		FillDirection = Enum.FillDirection.Horizontal,
		Padding = UDim.new(0, 6),
		SortOrder = Enum.SortOrder.LayoutOrder,
		VerticalAlignment = Enum.VerticalAlignment.Center,
	}, tabBar)

	-- isi
	local content = new("Frame", {
		BackgroundTransparency = 1,
		Position = UDim2.fromOffset(12, 88),
		Size = UDim2.new(1, -24, 1, -126),
		ClipsDescendants = true,
	}, window)

	statusLabel = new("TextLabel", {
		BackgroundTransparency = 1,
		Text = "",
		Font = Enum.Font.GothamMedium,
		TextSize = 13,
		TextWrapped = true,
		TextXAlignment = LEFT,
		AnchorPoint = Vector2.new(0, 1),
		Position = UDim2.new(0, 14, 1, -6),
		Size = UDim2.new(1, -28, 0, 30),
	}, window)

	local pages = {}
	local tabButtons = {}
	local function showTab(id)
		for tabId, page in pairs(pages) do
			page.Visible = tabId == id
		end
		for tabId, button in pairs(tabButtons) do
			button.BackgroundColor3 = tabId == id and roleDef.Color or COLORS.panel
		end
	end

	local firstId = nil
	for order, tab in ipairs(StaffConfig.PanelTabs) do
		if StaffConfig.RoleAtLeast(role, tab.Min) and builders[tab.Id] then
			local page = makePage(content)
			builders[tab.Id](page)
			pages[tab.Id] = page

			local button = makeButton(tabBar, tab.Label, COLORS.panel, function()
				showTab(tab.Id)
			end, UDim2.new(0, 0, 0, 32))
			button.AutomaticSize = Enum.AutomaticSize.X
			new("UIPadding", { PaddingLeft = UDim.new(0, 14), PaddingRight = UDim.new(0, 14) }, button)
			button.LayoutOrder = order
			tabButtons[tab.Id] = button

			firstId = firstId or tab.Id
		end
	end
	showTab(firstId)

	openButton.Activated:Connect(function()
		window.Visible = not window.Visible
	end)
end

local function refresh()
	local role = AdminsConfig.GetRank(player)
	local def = role and StaffConfig.Roles[role]
	if def and def.Panel then
		if builtRole ~= role then
			build(role)
		end
	else
		destroy()
	end
end

function StaffPanel.Toggle()
	if window then
		window.Visible = not window.Visible
	end
end

AdminsConfig.OnChanged(refresh)
refresh()

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then
		return
	end
	if input.KeyCode == StaffConfig.Panel.Key then
		StaffPanel.Toggle()
	end
end)

return StaffPanel
