-- StaffPoll (client): kartu polling yang dilihat semua pemain. Suara dikirim ke server.
-- Polling dibuat dari panel STAFF (tab Poll).
-- Letak di Studio: StarterPlayerScripts > Client > Controllers > StaffPoll (ModuleScript)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Remotes = require(ReplicatedStorage.Shared.Remotes)

local player = Players.LocalPlayer
local stateEvent = Remotes.Event("StaffPoll_State")
local voteEvent = Remotes.Event("StaffPoll_Vote")

local StaffPoll = {}

local LEFT = Enum.TextXAlignment.Left
local BG = Color3.fromRGB(24, 26, 34)
local ROW = Color3.fromRGB(44, 48, 62)
local BAR = Color3.fromRGB(70, 130, 240)
local PICKED = Color3.fromRGB(50, 160, 100)
local TEXT = Color3.fromRGB(235, 238, 245)
local MUTED = Color3.fromRGB(150, 156, 172)

local function new(className, props, parent)
	local instance = Instance.new(className)
	for key, value in pairs(props) do
		instance[key] = value
	end
	if parent then
		instance.Parent = parent
	end
	return instance
end

local gui = new("ScreenGui", {
	Name = "StaffPollGui",
	ResetOnSpawn = false,
	DisplayOrder = 55,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, player:WaitForChild("PlayerGui"))

local card = new("Frame", {
	Visible = false,
	AnchorPoint = Vector2.new(1, 0.5),
	Position = UDim2.new(1, -10, 0.5, 0),
	Size = UDim2.fromOffset(250, 0),
	AutomaticSize = Enum.AutomaticSize.Y,
	BackgroundColor3 = BG,
	BackgroundTransparency = 0.08,
	BorderSizePixel = 0,
}, gui)
new("UICorner", { CornerRadius = UDim.new(0, 12) }, card)
new("UIStroke", { Color = BAR, Thickness = 1.5 }, card)
new("UIPadding", {
	PaddingLeft = UDim.new(0, 12),
	PaddingRight = UDim.new(0, 12),
	PaddingTop = UDim.new(0, 10),
	PaddingBottom = UDim.new(0, 10),
}, card)
new("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, card)

local function makeText(text, size, color, order)
	return new("TextLabel", {
		BackgroundTransparency = 1,
		Text = text,
		Font = Enum.Font.GothamBold,
		TextSize = size,
		TextColor3 = color,
		TextXAlignment = LEFT,
		TextWrapped = true,
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		LayoutOrder = order,
	}, card)
end

local header = makeText("POLL", 12, BAR, 1)
local questionLabel = makeText("", 15, TEXT, 2)
local optionsFrame = new("Frame", {
	BackgroundTransparency = 1,
	Size = UDim2.new(1, 0, 0, 0),
	AutomaticSize = Enum.AutomaticSize.Y,
	LayoutOrder = 3,
}, card)
new("UIListLayout", { Padding = UDim.new(0, 5), SortOrder = Enum.SortOrder.LayoutOrder }, optionsFrame)
local timerLabel = makeText("", 12, MUTED, 4)

local current = nil
local myChoice = nil
local rows = {}
local hideToken = 0

local function clearRows()
	for _, row in ipairs(rows) do
		row.Button:Destroy()
	end
	rows = {}
end

local function buildRows()
	clearRows()
	for index, option in ipairs(current.Options) do
		local button = new("TextButton", {
			Text = "",
			AutoButtonColor = false,
			BackgroundColor3 = ROW,
			BorderSizePixel = 0,
			Size = UDim2.new(1, 0, 0, 34),
			LayoutOrder = index,
			ClipsDescendants = true,
		}, optionsFrame)
		new("UICorner", { CornerRadius = UDim.new(0, 8) }, button)

		local bar = new("Frame", {
			BackgroundColor3 = BAR,
			BackgroundTransparency = 0.55,
			BorderSizePixel = 0,
			Size = UDim2.fromScale(0, 1),
		}, button)

		local label = new("TextLabel", {
			BackgroundTransparency = 1,
			Text = "",
			Font = Enum.Font.GothamMedium,
			TextSize = 13,
			TextColor3 = TEXT,
			TextXAlignment = LEFT,
			Position = UDim2.fromOffset(10, 0),
			Size = UDim2.new(1, -20, 1, 0),
			TextTruncate = Enum.TextTruncate.AtEnd,
		}, button)

		button.Activated:Connect(function()
			if current and not current.Closed then
				myChoice = index
				voteEvent:FireServer(current.Id, index)
			end
		end)

		rows[index] = { Button = button, Bar = bar, Label = label, Option = option }
	end
end

local function render()
	if not current then
		return
	end

	questionLabel.Text = current.Question
	header.Text = current.Closed and "POLL CLOSED" or "POLL  -  by " .. tostring(current.By)

	local total = 0
	for _, count in ipairs(current.Counts) do
		total = total + count
	end

	for index, row in ipairs(rows) do
		local count = current.Counts[index] or 0
		local percent = total > 0 and math.floor(count / total * 100 + 0.5) or 0
		row.Label.Text = row.Option .. "   " .. count .. " (" .. percent .. "%)"
		row.Bar.Size = UDim2.fromScale(total > 0 and count / total or 0, 1)
		row.Button.BackgroundColor3 = myChoice == index and PICKED or ROW
	end
end

stateEvent.OnClientEvent:Connect(function(state)
	hideToken = hideToken + 1
	if type(state) ~= "table" then
		current = nil
		card.Visible = false
		return
	end

	local isNew = not current or current.Id ~= state.Id
	current = state
	if isNew then
		myChoice = nil
		buildRows()
	end
	card.Visible = true
	render()

	if state.Closed then
		local token = hideToken
		task.delay(20, function()
			if hideToken == token then
				card.Visible = false
			end
		end)
	end
end)

RunService.Heartbeat:Connect(function()
	if card.Visible and current and not current.Closed then
		local left = math.max(0, math.ceil(current.EndsAt - workspace:GetServerTimeNow()))
		timerLabel.Text = "Tap an option to vote  -  " .. left .. "s left"
	elseif current and current.Closed then
		timerLabel.Text = "Final results"
	end
end)

-- minta status polling yang sedang berjalan (kalau pemain masuk saat polling berlangsung)
voteEvent:FireServer(0)

return StaffPoll
